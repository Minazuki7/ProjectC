#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
vol_ajout a;
vol_ajout z;
void
on_b_gvol_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *acc_vols ;
GtkWidget *g_vols ;
GtkWidget *treeview_vols;
acc_vols=lookup_widget(button,"acc_vols");
gtk_widget_hide(acc_vols);
g_vols=create_g_vols();
gtk_widget_show(g_vols);
treeview_vols=lookup_widget(g_vols,"treeview_vols");
afficher_vols(treeview_vols,a);
}


void
on_a_vols_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *a_vols ;
GtkWidget *g_vols ;
g_vols=lookup_widget(button,"g_vols");
gtk_widget_hide(g_vols);
a_vols=create_a_vols();
gtk_widget_show(a_vols);
}


void
on_b_ajout3_clicked                    (GtkButton       *obj,
                                        gpointer         user_data)
{
vol_ajout z;
  GtkWidget *nomvol;
  GtkWidget *destination;
  GtkWidget *arriver;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *temp;
  GtkWidget *classe;
  GtkWidget *agance;
  GtkWidget *prixvol;


nomvol=lookup_widget(obj,"entry_nomvol");
destination=lookup_widget(obj,"entry_destination");
arriver=lookup_widget(obj,"entry_arriver");
jour=lookup_widget(obj,"vol_jour");
mois=lookup_widget(obj,"vol_mois");
annee=lookup_widget(obj,"vol_annee");
temp=lookup_widget(obj,"entry_temp");
classe=lookup_widget(obj,"combobox_classe");
agance=lookup_widget(obj,"combobox_agance");
prixvol=lookup_widget(obj,"entry_prixvol");



strcpy(z.nomvol,gtk_entry_get_text(GTK_ENTRY(nomvol)));
strcpy(z.dep,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(z.des,gtk_entry_get_text(GTK_ENTRY(arriver)));
z.vol_jour = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
z.vol_mois = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
z.vol_annee = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
strcpy(z.t_depart,gtk_entry_get_text(GTK_ENTRY(temp)));
strcpy(z.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));
strcpy(z.camp_air,gtk_combo_box_get_active_text(GTK_COMBO_BOX(agance)));
strcpy(z.v_prix,gtk_entry_get_text(GTK_ENTRY(prixvol)));
ajouter_vols (&z);
}


void
on_b_prec10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *a_vols ;
GtkWidget *g_vols ;
GtkWidget *treeview_vols ;
a_vols=lookup_widget(button,"a_vols");
gtk_widget_hide(a_vols);
g_vols=create_g_vols();
gtk_widget_show(g_vols);
treeview_vols=lookup_widget(g_vols,"treeview_vols");
afficher_vols(treeview_vols,a);
}


void
on_b_supp3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
dell_vol((char *)z.nomvol);
GtkWidget *w10 ;
GtkWidget *treeview_vols;
w10=lookup_widget(button,"g_vols");
gtk_widget_hide(w10);
w10=create_g_vols();
gtk_widget_show(w10);
treeview_vols=lookup_widget(w10,"treeview_vols");
afficher_vols(treeview_vols,a);
}


void
on_treeview_vols_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data,*str_data1,*str_data2,*str_data6,*str_data9;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data6, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 9, &str_data9, -1);
  }
strcpy(z.nomvol,str_data);
strcpy(z.dep,str_data1);
strcpy(z.des,str_data2);
strcpy(z.t_depart,str_data6);
strcpy(z.v_prix,str_data9);
}


void
on_m_vols_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id,*nom_hotels,*emplacement,*nb_etoil,*prix;
dell_vol((char *)z.nomvol);
GtkWidget *g_vols=lookup_widget(button,"g_vols");
GtkWidget *m_vols=lookup_widget(button,"m_vols");
gtk_widget_hide(g_vols);
m_vols=create_m_vols();
gtk_widget_show(m_vols);

id=lookup_widget(m_vols,"entry_nomvol1");
gtk_entry_set_text(GTK_ENTRY(id),z.nomvol);

nom_hotels=lookup_widget(m_vols,"entry_destination1");
gtk_entry_set_text(GTK_ENTRY(nom_hotels),z.dep);

emplacement=lookup_widget(m_vols,"entry_arriver1");
gtk_entry_set_text(GTK_ENTRY(emplacement),z.des);

emplacement=lookup_widget(m_vols,"entry_temp1");
gtk_entry_set_text(GTK_ENTRY(emplacement),z.t_depart);

prix=lookup_widget(m_vols,"entry_prixvol1");
gtk_entry_set_text(GTK_ENTRY(prix),z.v_prix);
}


void
on_b_modiff2_clicked                   (GtkButton       *obj,
                                        gpointer         user_data)
{
vol_ajout z;
  GtkWidget *nomvol;
  GtkWidget *destination;
  GtkWidget *arriver;
  GtkWidget *jour;
  GtkWidget *mois;
  GtkWidget *annee;
  GtkWidget *temp;
  GtkWidget *classe;
  GtkWidget *agance;
  GtkWidget *prixvol;


nomvol=lookup_widget(obj,"entry_nomvol1");
destination=lookup_widget(obj,"entry_destination1");
arriver=lookup_widget(obj,"entry_arriver1");
jour=lookup_widget(obj,"vol_jour1");
mois=lookup_widget(obj,"vol_mois1");
annee=lookup_widget(obj,"vol_annee1");
temp=lookup_widget(obj,"entry_temp1");
classe=lookup_widget(obj,"combobox_classe1");
agance=lookup_widget(obj,"combobox_agance1");
prixvol=lookup_widget(obj,"entry_prixvol1");



strcpy(z.nomvol,gtk_entry_get_text(GTK_ENTRY(nomvol)));
strcpy(z.dep,gtk_entry_get_text(GTK_ENTRY(destination)));
strcpy(z.des,gtk_entry_get_text(GTK_ENTRY(arriver)));
z.vol_jour = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
z.vol_mois = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
z.vol_annee = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
strcpy(z.t_depart,gtk_entry_get_text(GTK_ENTRY(temp)));
strcpy(z.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));
strcpy(z.camp_air,gtk_combo_box_get_active_text(GTK_COMBO_BOX(agance)));
strcpy(z.v_prix,gtk_entry_get_text(GTK_ENTRY(prixvol)));
ajouter_vols (&z);
}

