#include <gtk/gtk.h>
typedef struct vol_ajout
{
  char nomvol[20];
  char dep[20];
  char des[20];
  int vol_jour;
  int vol_mois;
  int vol_annee;
  char t_depart[20];
  char classe[20];
  char camp_air[20];
  char v_prix[20];
}vol_ajout;
void ajouter_vols (vol_ajout *a);
void afficher_vols (GtkListItem * liste,vol_ajout a);
void dell_vol(char *nomvol);
