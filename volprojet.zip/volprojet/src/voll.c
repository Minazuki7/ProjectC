#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"voll.h"
enum
{
 NOMVOLS,
 DEPARTV,
 ARRIVERV,
 JOURV,
 MOISV,
 ANNEEV,
 TEMPV,
 CLASSEV,
 AGENCEV,
 PRIXV,
 COLUMNS
};
void ajouter_vols (vol_ajout *a)
{
  FILE *f=fopen("voll.bin","ab+");
  if (f!=NULL)
    {
    fwrite(a,sizeof(vol_ajout),1,f);
    }
    fclose(f);
}
void afficher_vols (GtkListItem * liste,vol_ajout a)
{
  
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
       store=NULL;
  
           FILE*f;
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" nom du vol",renderer,"text",NOMVOLS, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" depart",renderer,"text",DEPARTV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" arriver",renderer,"text",ARRIVERV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          
   
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",JOURV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",MOISV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEEV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("temp du vol",renderer,"text",TEMPV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("classe",renderer,"text",CLASSEV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("campagnie",renderer,"text",AGENCEV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" prix du vol",renderer,"text",PRIXV, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_UINT, G_TYPE_UINT, G_TYPE_UINT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
      int i=0;
      f= fopen("voll.bin","rb");
      while(!(feof(f)))
        {
           fread(&a,sizeof(vol_ajout),1,f);
             i++;
             }
       fclose(f);
       f=fopen("voll.bin","rb");
      if(f!=NULL) 
        {
           int j=0; 
             while(j<i-1)
              {
                fread(&a,sizeof(vol_ajout),1,f);
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter,NOMVOLS,a.nomvol,DEPARTV,a.dep,ARRIVERV,a.des,JOURV,a.vol_jour,MOISV, a.vol_mois,ANNEEV,a.vol_annee,TEMPV,a.t_depart,CLASSEV,a.classe,AGENCEV,a.camp_air,PRIXV,a.v_prix, -1); 
         j++;   }
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}


void dell_vol(char *nomvol)
{
vol_ajout a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("voll_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("voll.bin","rb");
new=fopen("voll_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(vol_ajout),old);
	}
fclose(old);
old=fopen("voll.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&a,1,sizeof(vol_ajout),old);
	
	if(strcmp(a.nomvol,nomvol))
		{	
		fwrite(&a,sizeof(vol_ajout),1,new);
		}
	}
fclose(new);
fclose(old);
remove("voll.bin");//nfas5ou il fichier li9dim
rename("voll_test.bin","voll.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}



