#include <gtk/gtk.h>
#include"voll.h"

void
on_b_gvol_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_a_vols_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_ajout3_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_prec10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_supp3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_vols_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_m_vols_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_b_modiff2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
