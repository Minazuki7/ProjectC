#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include "ajc.h"
#include <gtk/gtk.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1 ; 
  GtkWidget *window2 ; 
gtk_widget_destroy(window1);
window2=create_window2();
gtk_widget_show(window2);
}





void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2 ;
GtkWidget *window3;
window3=lookup_widget(GTK_WIDGET(button),"window3") ;
gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
  client c ;
GtkWidget *j,*m , *y;
GtkWidget *jj,*mm,*yy;
GtkWidget *cob2;
GtkWidget *marque=lookup_widget(GTK_WIDGET(button),"marque");
j = lookup_widget(GTK_WIDGET(button),"j");
m = lookup_widget(GTK_WIDGET(button),"m");
y = lookup_widget(GTK_WIDGET(button),"y");

jj = lookup_widget(GTK_WIDGET(button),"jj");
mm = lookup_widget(GTK_WIDGET(button),"mm");
yy = lookup_widget(GTK_WIDGET(button),"yy");

cob2=lookup_widget(GTK_WIDGET(button),"cob2");
c.dd.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
c.dd.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
c.dd.y=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(y));

c.da.jj=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
c.da.mm=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
c.da.aa=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(yy));

strcpy(c.lp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(cob2)));
strcpy(c.marq,gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));
ajouter(c);

}


void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2 ;
GtkWidget *window3;
GtkWidget *treeview1;

window2=lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_destroy(window2);
window3=lookup_widget(GTK_WIDGET(button),"window3") ;
window3=create_window3();
gtk_widget_show(window3);

treeview1=lookup_widget(window3,"treeview1"); 
affiche_persons(treeview1); 
}




void
on_button10_clicked    (GtkWidget *button,
                                        gpointer         user_data)
{
GtkWidget *sortie;
sortie=lookup_widget(button,"label5");
gtk_label_set_text(GTK_LABEL(sortie),"Reservation reussite");
}

