#include"ajc.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>

enum 
{
    TEST,
    DT_DEPART,
    DT_RETOUR,
    LP,
    COLUMNS
};

void ajouter(client c)
{
   FILE *f;
f=fopen("voitureres.txt","a+"); 
if(f!=NULL) 
{ 
fprintf(f,"%d %d %d %d %d %d %s %s\n",c.dd.j,c.dd.m,c.dd.y,c.da.jj,c.da.mm,c.da.aa,c.lp,c.marq);
}
fclose(f); 

}

void affiche_persons(GtkWidget *show)
{

      client c;
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter *miter;
      GtkListStore *store ;

      FILE *f ;

      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(store==NULL)
       {

          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date de depart",render,"text",DT_DEPART,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Date d'arriver",render,"text",DT_RETOUR,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Marque",render,"text",TEST,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);  

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Lieu",render,"text",LP,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

 
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


   f=fopen("voitureres.txt","r");
if (f==NULL)
{
return;
}
else
{
   // f= fopen("voitureres.txt","a+");
    while(fscanf(f,"%d %d %d %d %d %d %s %s \n",&c.dd.j,&c.dd.m,&c.dd.y,&c.da.jj,&c.da.mm,&c.da.aa,c.lp,c.marq)!=EOF)
    {
char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_depart[20]="";
char dt_retour[20]="";

sprintf(r1,"%d",c.dd.j);
strcat(dt_depart,r1);
strcat(dt_depart,"/");
sprintf(r2,"%d",c.dd.m);
strcat(dt_depart,r2);
strcat(dt_depart,"/");
sprintf(r3,"%d",c.dd.y);
strcat(dt_depart,r3);

sprintf(r4,"%d",c.da.jj);
strcat(dt_retour,r4);
strcat(dt_retour,"/");
sprintf(r5,"%d",c.da.mm);
strcat(dt_retour,r5);
strcat(dt_retour,"/");
sprintf(r6,"%d",c.da.aa);
strcat(dt_retour,r6);


gtk_list_store_append(store,&miter);
gtk_list_store_set(store,&miter,DT_DEPART,dt_depart,DT_RETOUR,dt_retour,LP,c.lp,TEST,c.marq,-1);
}
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);
}
}

