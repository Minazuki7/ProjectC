#include<gtk/gtk.h>
typedef struct 
{
    int j ,  m , y;
    
}date;
typedef struct
{
int jj;
int mm;
int aa;
}Date1;

typedef struct 
{   
    
    date dd;
    Date1 da;
    char lp[20];
 char marq[20];

}client;

void ajouter(client c);
void affiche_persons(GtkWidget *show);
