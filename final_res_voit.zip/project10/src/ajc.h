#ifndef AJC_H_
#define AJC_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_vol
{
int jour;
int mois;
int annee;
}date;

typedef struct
{ 
date aller;
date retour;
char marq[20];
char lp[20];
}client;

void ajouter (client *c); 
void afficher (GtkWidget *liste,client c);
void dell_user(char *marq);
#endif
