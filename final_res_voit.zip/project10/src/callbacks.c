#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ajc.h"
#include "ajg.h"
client c ;
agent a;
client d;
void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_destroy(window1);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
gtk_widget_destroy(window1);
window4=create_window4();
gtk_widget_show(window4);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
client c;

GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jr");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"ms");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"an");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(button),"jr1");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(button),"ms1");
GtkWidget *an1=lookup_widget(GTK_WIDGET(button),"an1");
GtkWidget *marque=lookup_widget(GTK_WIDGET(button),"marque");
GtkWidget *lieu=lookup_widget(GTK_WIDGET(button),"lieu");


c.aller.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
c.aller.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
c.aller.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

c.retour.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
c.retour.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
c.retour.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));

strcpy(c.marq,gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));
strcpy(c.lp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lieu)));

ajouter(&c);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *marque;
GtkWidget *sortie;
sortie=lookup_widget(button,"label5");
gtk_label_set_text(GTK_LABEL(sortie),"Reservation reussite :) ");

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
client c;
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");

GtkWidget *treeview1;
gtk_widget_destroy(window2);
window3=create_window3();
gtk_widget_show(window3);

treeview1=lookup_widget(window3,"treeview1");
afficher (treeview1,c);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data, -1);
  }
strcpy(c.marq,str_data);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

dell_user((char *)c.marq);

GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
GtkWidget *treeview1;

treeview1=lookup_widget(window3,"treeview1");

afficher(treeview1,c);
gtk_widget_show(treeview1);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}


void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
agent a;

GtkWidget *jrr=lookup_widget(GTK_WIDGET(button),"jrr");
GtkWidget *mss=lookup_widget(GTK_WIDGET(button),"mss");
GtkWidget *ann=lookup_widget(GTK_WIDGET(button),"ann");
GtkWidget *jrr1=lookup_widget(GTK_WIDGET(button),"jrr1");
GtkWidget *mss1=lookup_widget(GTK_WIDGET(button),"mss1");
GtkWidget *ann1=lookup_widget(GTK_WIDGET(button),"ann1");
GtkWidget *marquee=lookup_widget(GTK_WIDGET(button),"marquee");
GtkWidget *lieuu=lookup_widget(GTK_WIDGET(button),"lieuu");
GtkWidget *entry1=lookup_widget(GTK_WIDGET(button),"entry1");

a.d.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrr));
a.d.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mss));
a.d.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ann));

a.r.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrr1));
a.r.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mss1));
a.r.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ann1));

strcpy(a.marq,gtk_combo_box_get_active_text(GTK_COMBO_BOX(marquee)));
strcpy(a.lp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lieuu)));
strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(entry1)));
ajout(&a);
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
agent a;
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *window5=lookup_widget(GTK_WIDGET(button),"window5");

GtkWidget *treeview2;
gtk_widget_destroy(window4);
window5=create_window5();
gtk_widget_show(window5);

treeview2=lookup_widget(window5,"treeview2");
affich (treeview2,a);
}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sortie;
sortie=lookup_widget(button,"label18");
gtk_label_set_text(GTK_LABEL(sortie),"Reservation reussite :) ");
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *st_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0, &st_data, -1);
  }
strcpy(a.id,st_data);
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
dell_a((char *)a.id);

GtkWidget *window5=lookup_widget(GTK_WIDGET(button),"window5");
GtkWidget *treeview2;

treeview2=lookup_widget(window5,"treeview2");

affich(treeview2,a);
gtk_widget_show(treeview2);
}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *t;
dell_a((char *)a.id);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window4=lookup_widget(button,"window4");
GtkWidget *window5=lookup_widget(button,"window5");
gtk_widget_hide(window5);
window4=create_window4();
gtk_widget_show(window4);
t=lookup_widget(window4,"entry1");
gtk_entry_set_text(GTK_LABEL(t),a.id);
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *window5=lookup_widget(GTK_WIDGET(button),"window5");
gtk_widget_destroy(window5);
window4=create_window4();
gtk_widget_show(window4);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
dell_user((char *)c.marq);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window3=lookup_widget(button,"window3");
GtkWidget *window2=lookup_widget(button,"window2");
gtk_widget_hide(window3);
window2=create_window2();
gtk_widget_show(window2);
}

