#ifdef HAVE_CONFIG_H
#  include <config.h>

#endif

#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclam.h"
#include <string.h>
reclam r;
char dt1[20];
void on_Valider_clicked (GtkButton *button, gpointer user_data)
{
reclam r;
GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jr");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"ms");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"an");
GtkWidget *serv=lookup_widget(GTK_WIDGET(button),"serv");
GtkWidget *txt=lookup_widget(GTK_WIDGET(button),"txt");
GtkWidget *log=lookup_widget(GTK_WIDGET(button),"log");
if((strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(serv)),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(txt))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(log))),"")==0))
{
GtkWidget *vide;
vide=create_vide() ;
gtk_widget_show(vide) ;
}
else
{
r.date.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
r.date.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
r.date.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));
strcpy(r.type_serv,gtk_combo_box_get_active_text(GTK_COMBO_BOX(serv)));
strcpy(r.text,gtk_entry_get_text(GTK_ENTRY(txt)));
strcpy(r.log,gtk_entry_get_text(GTK_ENTRY(log)));
ajouter(&r);
GtkWidget *Valide;
Valide=create_Valide() ;
gtk_widget_show(Valide) ;

}
}
void on_ajout_reclam_clicked (GtkButton *button,gpointer user_data)
{
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
GtkWidget *Ajout_reclam=lookup_widget(GTK_WIDGET(button),"Ajout_reclam");
gtk_widget_destroy(Reclam);
Ajout_reclam=create_Ajout_reclam();
gtk_widget_show(Ajout_reclam);
}

void on_retour_clicked (GtkButton *button,gpointer user_data)
{
reclam r;
GtkWidget *affich;
GtkWidget *Ajout_reclam=lookup_widget(GTK_WIDGET(button),"Ajout_reclam");
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
Reclam=create_Reclam();
gtk_widget_show(Reclam);
gtk_widget_destroy(Ajout_reclam);
affich=lookup_widget(Reclam,"affich");
afficher (affich,r);
}

void on_quitter_reclam_clicked (GtkButton *button,gpointer user_data)
{
gtk_main_quit();
}


void
on_quitte_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;
GtkWidget *suppr_admin=lookup_widget(GTK_WIDGET(button),"suppr_admin");
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
Reclam=create_Reclam();
gtk_widget_show(Reclam);
gtk_widget_destroy(suppr_admin);
  GtkWidget *affich;
  affich=lookup_widget(Reclam,"affich");
  afficher (affich,r);
}


void
on_admin_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;
GtkWidget *suppr_admin=lookup_widget(GTK_WIDGET(button),"suppr_admin");
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
suppr_admin=create_suppr_admin();
gtk_widget_show(suppr_admin);
gtk_widget_destroy(Reclam);
  GtkWidget *reclam_admin;
  reclam_admin=lookup_widget(suppr_admin,"reclam_admin");
  afficher_resv(reclam_admin,r,dt1);
}


void
on_reclam_admin_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data, -1);
  }
strcpy(r.text,str_data);
}

void
on_supp_admin_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
dell_user_rep((char *)r.text);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *suppr_admin=lookup_widget(GTK_WIDGET(button),"suppr_admin");
GtkWidget *reclam_admin;
gtk_widget_destroy(suppr_admin);
suppr_admin=create_suppr_admin();
gtk_widget_show(suppr_admin);
reclam_admin=lookup_widget(suppr_admin,"reclam_admin");
  afficher_resv(reclam_admin,r,dt1);
gtk_widget_show(reclam_admin);

}
void
on_agent_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;

GtkWidget *reclamtion_agent=lookup_widget(GTK_WIDGET(button),"reclamtion_agent");
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
GtkWidget *reclam_agent;
gtk_widget_destroy(Reclam);
reclamtion_agent=create_reclamtion_agent();
gtk_widget_show(reclamtion_agent);

  
  reclam_agent=lookup_widget(reclamtion_agent,"reclam_agent");
  afficher (reclam_agent,r);
}




void
on_quitter_agent_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;
GtkWidget *reclamtion_agent=lookup_widget(GTK_WIDGET(button),"reclamtion_agent");
GtkWidget *Reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
Reclam=create_Reclam();
gtk_widget_show(Reclam);
gtk_widget_destroy(reclamtion_agent);
  GtkWidget *affich;
  affich=lookup_widget(Reclam,"affich");
  afficher (affich,r);
}

void
on_reclam_agent_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data1,*str_data2,*str_data3,*str_data4;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data3, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data4, -1);
  }
strcpy(r.log,str_data1);
strcpy(dt1,str_data2);
strcpy(r.type_serv,str_data3);
strcpy(r.text,str_data4);
}
void
on_affich_row_activated                (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data1,*str_data2,*str_data3;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0, &str_data1, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data2, -1);
//gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data3, -1);
  }
strcpy(r.log,str_data1);
strcpy(r.text,str_data2);
//strcpy(r.text,str_data2);
}
void
on_repondre_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamtion_agent=lookup_widget(button,"reclamtion_agent");
GtkWidget *Repondre_reclam=lookup_widget(button,"Repondre_reclam");
gtk_widget_destroy(reclamtion_agent);
Repondre_reclam=create_Repondre_reclam();
gtk_widget_show(Repondre_reclam);
GtkWidget *label=lookup_widget(Repondre_reclam,"label46");
gtk_label_set_text(GTK_LABEL(label),r.text);

}


void
on_ok_repondre_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *repondre=lookup_widget(GTK_WIDGET(button),"repondre");
strcpy(r.repd,gtk_entry_get_text(GTK_ENTRY(repondre)));
//strcpy(rp,r.repd)
ajouter_repd (&r);
}


void

on_retour_repondre_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;
GtkWidget *reclamtion_agent=lookup_widget(GTK_WIDGET(button),"reclamtion_agent");
GtkWidget *Repondre_reclam=lookup_widget(GTK_WIDGET(button),"Repondre_reclam");
GtkWidget *reclam_agent;
gtk_widget_destroy(Repondre_reclam);
reclamtion_agent=create_reclamtion_agent();
gtk_widget_show(reclamtion_agent);
  reclam_agent=lookup_widget(reclamtion_agent,"reclam_agent");
  afficher (reclam_agent,r);
}


void
on_modifer_client_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
dell_user((char *)r.text);
GtkWidget *reclamtion_agent=lookup_widget(button,"reclamtion_agent");
GtkWidget *Ajout_reclam=lookup_widget(button,"Ajout_reclam");
GtkWidget *log,*txt;

/*****Na3mlo Actualiser lil liste **************/


//nom=lookup_widget(fenetre_ajout,"serv");
//gtk_entry_set_text(GTK_LABEL(nom),z.nom);


gtk_widget_destroy(reclamtion_agent);
Ajout_reclam=create_Ajout_reclam();
gtk_widget_show(Ajout_reclam);
txt=lookup_widget(Ajout_reclam,"log");
gtk_entry_set_text(GTK_LABEL(txt),r.log);
txt=lookup_widget(Ajout_reclam,"txt");
gtk_entry_set_text(GTK_LABEL(txt),r.text);
}


void
on_affich_rep_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
//reclam r;
GtkWidget *rep_recl=lookup_widget(GTK_WIDGET(button),"rep_recl");
GtkWidget *reclam=lookup_widget(GTK_WIDGET(button),"Reclam");
GtkWidget *affich_rep;
gtk_widget_destroy(reclam);
rep_recl=create_rep_recl();
gtk_widget_show(rep_recl);
affich_rep=lookup_widget(rep_recl,"affich_rep");
afficher_resv(affich_rep,r,dt1);
}


void
on_affich_recl_rep_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *reclamtion_agent=lookup_widget(GTK_WIDGET(button),"reclamtion_agent");
GtkWidget *rep_recl=lookup_widget(GTK_WIDGET(button),"rep_recl");
rep_recl=create_rep_recl();
gtk_widget_show(rep_recl);
gtk_widget_destroy(reclamtion_agent);
GtkWidget *affich_rep;
affich_rep=lookup_widget(rep_recl,"affich_rep");
afficher_resv(affich_rep,r,dt1);
}


void
on_quitter_rep_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
reclam r;
GtkWidget *reclamtion_agent=lookup_widget(GTK_WIDGET(button),"reclamtion_agent");
GtkWidget *rep_recl=lookup_widget(GTK_WIDGET(button),"rep_recl");
GtkWidget *reclam_agent;
gtk_widget_destroy(rep_recl);
reclamtion_agent=create_reclamtion_agent();
gtk_widget_show(reclamtion_agent);
  reclam_agent=lookup_widget(reclamtion_agent,"reclam_agent");
  afficher (reclam_agent,r);
}


void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *vide=lookup_widget(GTK_WIDGET(button),("vide"));

gtk_widget_destroy(vide);
}


void
on_closebutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *vide=lookup_widget(GTK_WIDGET(button),("vide"));

gtk_widget_destroy(vide);
}

