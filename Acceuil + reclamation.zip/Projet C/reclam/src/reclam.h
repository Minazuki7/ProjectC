#ifndef RECLAM_H_
#define RECALM_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_de_reclam
{
int jour;
int mois;
int annee;
}dt;

typedef struct reclamation
{
dt date;
char type_serv[20];
char text[20];
char repd[20];
char log[20];
}reclam;

void ajouter_repd (reclam *r);
void ajouter(reclam *r);

void afficher (GtkWidget *liste,reclam r);
void afficher_resv (GtkWidget *liste,reclam r, char dt[]);

void dell_user(char *text);
void dell_user_rep(char *text);
#endif
