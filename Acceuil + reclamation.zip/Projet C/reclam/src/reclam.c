#include "reclam.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{
 LOG,
 DATE,
 TYPE,
 TEXT,
 COLUMNS
};
enum
{
 LOG1,
 DATE1,
 TYPE1,
 TEXT1,
 REP,
 COLUMNS1
};
int a=0;

void ajouter_repd (reclam *r)
{
FILE *f;
f=fopen("reclam_rep.bin","ab"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(r,sizeof(reclam),1,f);
fclose(f); } //fermeture du fichier
}


void ajouter (reclam *r)
{
FILE *f;
f=fopen("reclam.bin","ab"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(r,sizeof(reclam),1,f); 
}
fclose(f); //fermeture du fichier
}


void afficher (GtkWidget *liste,reclam r)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
char repd[20]="";
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Login", renderer,"text",LOG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Date de service", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Type de service", renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reclamation", renderer,"text",TEXT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
int i=0;
f=fopen("reclam.bin","rb"); 
while (!(feof(f)))
{
fread(&r,sizeof(reclam),1,f);
i++;
}
fclose(f);
f=fopen("reclam.bin","rb");
if (f!=NULL)
{int j=0;
while (j<i-1)
{
fread(&r,sizeof(reclam),1,f);
char r1[20];
char r2[20];
char r3[20];
char dt_date[20]="";
char vid[20]="";
sprintf(r1,"%d",r.date.jour);
strcat(dt_date,r1);
strcat(dt_date,"/");

sprintf(r2,"%d",r.date.mois);
strcat(dt_date,r2);
strcat(dt_date,"/");

sprintf(r3,"%d",r.date.annee);
strcat(dt_date,r3);

gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DATE,dt_date,TYPE,r.type_serv,TEXT,r.text,LOG,r.log,-1);
j++;
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void dell_user(char *text)
{
reclam r;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("reclam_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("reclam.bin","rb");
new=fopen("reclam_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&r,1,sizeof(reclam),old);
	}
fclose(old);
old=fopen("reclam.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&r,1,sizeof(reclam),old);
	if(strcmp(r.text,text))
		{	
		fwrite(&r,sizeof(reclam),1,new);
		}
	}
fclose(new);
fclose(old);
remove("reclam.bin");//nfas5ou il fichier li9dim
rename("reclam_test.bin","reclam.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}
void afficher_resv (GtkWidget *liste,reclam r, char dt[])
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
//char repd[20]="";
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Login", renderer,"text",LOG1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Date de service", renderer,"text",DATE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Type de service", renderer,"text",TYPE1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reclamation", renderer,"text",TEXT1,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Repondre", renderer,"text",REP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

store= gtk_list_store_new (COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
int i=0;
f=fopen("reclam_rep.bin","rb"); 
while (!(feof(f)))
{
fread(&r,sizeof(reclam),1,f);
i++;
}
fclose(f);
f=fopen("reclam_rep.bin","rb");
if (f!=NULL)
{int j=0;
while (j<i-1)
{
fread(&r,sizeof(reclam),1,f);
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DATE1,dt,TYPE1,r.type_serv,TEXT1,r.text,LOG1,r.log,REP,r.repd,-1);
j++;
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}
dell_user_rep(char *text)
{
reclam r;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("reclam_rep_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("reclam_rep.bin","rb");
new=fopen("reclam_rep_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&r,1,sizeof(reclam),old);
	}
fclose(old);
old=fopen("reclam_rep.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&r,1,sizeof(reclam),old);
	if(strcmp(r.text,text))
		{	
		fwrite(&r,sizeof(reclam),1,new);
		}
	}
fclose(new);
fclose(old);
remove("reclam_rep.bin");//nfas5ou il fichier li9dim
rename("reclam_rep_test.bin","reclam_rep.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}

