#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "login.h"

void on_button_valider_clicked (GtkButton *button,gpointer user_data)
{
gchar test[20];
int r;

GtkWidget *login=lookup_widget(GTK_WIDGET(button),"login");
GtkWidget *mdp=lookup_widget(GTK_WIDGET(button),"mdp");
if((strcmp((gtk_entry_get_text(GTK_ENTRY(login))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),"")==0))
{
GtkWidget *Attention;
Attention=create_Attention() ;
gtk_widget_show(Attention) ;
}
else
{
if(verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)))==1)
{
GtkWidget *conferm;
conferm=create_conferm() ;
gtk_widget_show(conferm) ;
}
else if (verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)))==2)
{
GtkWidget *conferm;
conferm=create_conferm() ;
gtk_widget_show(conferm) ;
}
else if (verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)))==-1)
{
GtkWidget *Attention;
Attention=create_Attention() ;
gtk_widget_show(Attention) ;
}
}
}
void on_button_quitter_clicked (GtkButton *button,gpointer user_data)
{
gtk_main_quit();
}
void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Attention=lookup_widget(GTK_WIDGET(button),("Attention"));

gtk_widget_destroy(Attention);
}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *conferm=lookup_widget(GTK_WIDGET(button),("conferm"));

gtk_widget_destroy(conferm);
}

