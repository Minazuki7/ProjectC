#include <gtk/gtk.h>


void
on_mdp_changed                         (GtkEditable     *editable,
                                        gpointer         user_data);

void
on_button_valider_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
