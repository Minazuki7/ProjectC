#ifndef LOGIN_H_
#define LOGIN_H_
#include <gtk/gtk.h>
typedef struct 
{char nom_hotel[20];
char adresse[20];
char etoile[10];
char num_responsable[20];
}hotel;
void afficher_hotel (GtkWidget * liste,hotel h);
int verifier (char log[],char mdp[]);
#endif
