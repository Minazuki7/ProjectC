#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "login.h"
enum
{
 HOTEL,
 ADRESSE,
 ETOILES,
 NUMERO,
 COLUMNS
};

typedef struct authentification
{
char login[20], password [20];
int role;
}auth;
int verifier (char log[],char mdp[])
{
int r;
auth a;
FILE *f;
r=0;
int i=0;
f=fopen("login.txt","r");
if(f !=NULL) {
while((fscanf(f,"%s %s %d \n",a.login,a.password,&a.role)!=EOF)) //parcours du fichier
{
if(strcmp(a.login,log)==0)
{ 
  if (strcmp(a.password,mdp)==0)
  r=a.role;
}
else if(r==0) 
{
r=-1;
}}
return r ;
}}

void afficher_hotel(GtkWidget *show,hotel h)
{
    
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter miter;
      GtkListStore *store ;
     
      char nom_hotel[20];
      char adresse[20];
      char etoile[10];
      char num_responsable[20];
    store = NULL;
     
      //FILE *f ;
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(!store){
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("hotel",render,"text",HOTEL,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("adresse",render,"text",ADRESSE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("etoiles",render,"text",ETOILES,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("responsable",render,"text",NUMERO,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          
          
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


      FILE *f = fopen("ajout_hotel","rb") ;
      if(!f) exit(-1);

      while(fread(&h,sizeof(hotel),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          
          gtk_list_store_set(store,&miter,HOTEL,h.nom_hotel,ADRESSE,h.adresse,ETOILES,h.etoile,NUMERO,h.num_responsable);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);

}
