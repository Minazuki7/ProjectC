#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reservation.h"
#include <string.h>

ReservationVol v;
hotel h;
char tt[50];
void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window1");
gtk_widget_hide(w1);
w2=create_window6();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview3");
afficher_hotel_clientReserver(treeview1);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window1");
gtk_widget_hide(w1);
w2=create_window8();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview5");
afficher_hotel_agentReserver(treeview1);
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  w1=lookup_widget(button,"window1");
  gtk_widget_destroy(w1);
  w2=create_window4();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview2");
afficher_vol_agent(treeview1);

}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window1");
gtk_widget_hide(w1);
w2=create_window2();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview1");
afficher_vol(treeview1);

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
dell_vol_client(v);

GtkWidget *w2=lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_hide(w2);
w2=create_window2();
gtk_widget_show(w2);
GtkWidget *treeview1;

treeview1=lookup_widget(w2,"treeview1");
afficher_vol(treeview1);


}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window2");
gtk_widget_hide(w1);
w2=create_window3();
gtk_widget_show(w2);
}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window2");
gtk_widget_hide(w1);
w2=create_window1();
gtk_widget_show(w2);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
  ReservationVol d;
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
d=mod_vol_client(v);
/*****Na3mlo Actualiser lil liste **************/

GtkWidget *fenetre_afficher;
GtkWidget *fenetre_ajout;


fenetre_afficher=lookup_widget(button,"window2");
gtk_widget_hide(fenetre_afficher);
fenetre_ajout=create_window3();
gtk_widget_show(fenetre_ajout);

}


void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
GtkWidget *Combobox4;
GtkWidget *entry7;
GtkWidget *label15;

ReservationVol tab;

char classe[50];

char compagnie[50];

char de[50];

char a[50];

Date dt_depart;


char hr_depart[50];


Jour=lookup_widget(button,"jour");
Mois=lookup_widget(button,"mois");
Annee=lookup_widget(button,"annee");
Combobox1=lookup_widget(button,"combobox1");
Combobox2=lookup_widget(button,"combobox2");
Combobox3=lookup_widget(button,"combobox3");
Combobox4=lookup_widget(button,"combobox4");
entry7=lookup_widget(button,"entry7");
label15=lookup_widget(button,"label15");


dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));





strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));

strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));

strcpy(classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));

strcpy(compagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox4)));

strcpy(hr_depart,gtk_entry_get_text(GTK_ENTRY(entry7)));



GtkWidget *w1,*w2;
char r[500];

sprintf (r, "%f", vol_confirmation(tab,classe,compagnie,dt_depart,hr_depart,de,a));
if (vol_confirmation(tab,classe,compagnie,dt_depart,hr_depart,de,a) !=0)
{
char  tmp[50]="Le montant total est :";
strcat(tmp,r);
strcat(tmp," DT");
gtk_label_set_text(GTK_LABEL(label15),tmp);
}
else
gtk_label_set_text(GTK_LABEL(label15),"pas de vol compatible");


}

void
on_button11_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
GtkWidget *Combobox4;
GtkWidget *entry7;
GtkWidget *sortie;
ReservationVol s;

Combobox1=lookup_widget(button,"combobox1");
sortie=lookup_widget(button,"label15");
Combobox2=lookup_widget(button,"combobox2");


Jour=lookup_widget(button,"jour");
Mois=lookup_widget(button,"mois");
Annee=lookup_widget(button,"annee");
entry7=lookup_widget(button,"entry7");

Combobox3=lookup_widget(button,"combobox3");
Combobox4=lookup_widget(button,"combobox4");




strcpy(s.de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
strcpy(s.a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));

s.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
s.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
s.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));



strcpy(s.hr_depart,gtk_entry_get_text(GTK_ENTRY(entry7)));


strcpy(s.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));

strcpy(s.compagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox4)));
float ff=vol_confirmation(s,s.classe,s.compagnie,s.dt_depart,s.hr_depart,s.de,s.a);
if (ff !=0)
{
reserver_vol(s,ff);
gtk_label_set_text(GTK_LABEL(sortie),"reservation reussite");
}
else
gtk_label_set_text(GTK_LABEL(sortie),"erreur d'ajout");
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  w1=lookup_widget(button,"window3");
  gtk_widget_destroy(w1);
  w2=create_window2();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview1");
afficher_vol(treeview1);
}


void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window3");
gtk_widget_hide(w1);
w2=create_window2();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview1");
afficher_vol(treeview1);
}


void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window4");
gtk_widget_hide(w1);
w2=create_window1();
gtk_widget_show(w2);
}


void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  ReservationVol d;
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
d=mod_vol_agent(v);
/*****Na3mlo Actualiser lil liste **************/

GtkWidget *fenetre_afficher;
GtkWidget *fenetre_ajout;

fenetre_afficher=lookup_widget(button,"window4");
gtk_widget_hide(fenetre_afficher);
fenetre_ajout=create_window5();
gtk_widget_show(fenetre_ajout);

}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

dell_vol_agent(v);
GtkWidget *w4=lookup_widget(GTK_WIDGET(button),"window4");
gtk_widget_hide(w4);
w4=create_window4();
gtk_widget_show(w4);

GtkWidget *treeview2;

treeview2=lookup_widget(w4,"treeview2");
afficher_vol_agent(treeview2);




}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window4");
gtk_widget_hide(w1);
w2=create_window5();
gtk_widget_show(w2);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
GtkWidget *Combobox4;
GtkWidget *entry2;
GtkWidget *entry8;
GtkWidget *label35;

ReservationVol tab;

char id[50];

char classe[50];

char compagnie[50];

char de[50];

char a[50];

Date dt_depart;


char hr_depart[50];


Jour=lookup_widget(button,"spinbutton4");
Mois=lookup_widget(button,"spinbutton5");
Annee=lookup_widget(button,"spinbutton6");
Combobox1=lookup_widget(button,"combobox5");
Combobox2=lookup_widget(button,"combobox6");
Combobox3=lookup_widget(button,"combobox13");
Combobox4=lookup_widget(button,"combobox14");
entry2=lookup_widget(button,"entry2");
entry8=lookup_widget(button,"entry8");
label35=lookup_widget(button,"label35");

strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry2)));


dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));





strcpy(de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));

strcpy(a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));

strcpy(classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));

strcpy(compagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox4)));

strcpy(hr_depart,gtk_entry_get_text(GTK_ENTRY(entry8)));



GtkWidget *w1,*w2;
char r[500];

sprintf (r, "%f", vol_confirmation(tab,classe,compagnie,dt_depart,hr_depart,de,a));
if (vol_confirmation(tab,classe,compagnie,dt_depart,hr_depart,de,a) !=0)
{
char  tmp[50]="Le montant total est :";
strcat(tmp,r);
strcat(tmp," DT");
gtk_label_set_text(GTK_LABEL(label35),tmp);
}
else
gtk_label_set_text(GTK_LABEL(label35),"pas de vol compatible");

}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Jour;
GtkWidget *Mois;
GtkWidget *Annee;
GtkWidget *Combobox1;
GtkWidget *Combobox2;
GtkWidget *Combobox3;
GtkWidget *Combobox4;
GtkWidget *entry2;
GtkWidget *entry8;
GtkWidget *sortie;
ReservationVol s;

Combobox1=lookup_widget(button,"combobox5");
sortie=lookup_widget(button,"label35");
Combobox2=lookup_widget(button,"combobox6");


Jour=lookup_widget(button,"spinbutton4");
Mois=lookup_widget(button,"spinbutton5");
Annee=lookup_widget(button,"spinbutton6");
entry2=lookup_widget(button,"entry2");
entry8=lookup_widget(button,"entry8");

Combobox3=lookup_widget(button,"combobox13");
Combobox4=lookup_widget(button,"combobox14");

strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(entry2)));




strcpy(s.de,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
strcpy(s.a,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));

s.dt_depart.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Jour));
s.dt_depart.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Mois));
s.dt_depart.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Annee));



strcpy(s.hr_depart,gtk_entry_get_text(GTK_ENTRY(entry8)));


strcpy(s.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox3)));

strcpy(s.compagnie,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox4)));
float ff=vol_confirmation(s,s.classe,s.compagnie,s.dt_depart,s.hr_depart,s.de,s.a);
if (ff !=0)
{
reserver_vol_agent(s,ff);
gtk_label_set_text(GTK_LABEL(sortie),"reservation reussite");
}
else
gtk_label_set_text(GTK_LABEL(sortie),"erreur d'ajout");
}




void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  w1=lookup_widget(button,"window5");
  gtk_widget_destroy(w1);
  w2=create_window4();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview2");
afficher_vol_agent(treeview1);
}


void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  w1=lookup_widget(button,"window5");
  gtk_widget_destroy(w1);
  w2=create_window4();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview2");
afficher_vol_agent(treeview1);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window6");
gtk_widget_hide(w1);
w2=create_window1();
gtk_widget_show(w2);
}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
dell_hotel_client(h);
GtkWidget *w6=lookup_widget(GTK_WIDGET(button),"window6");
gtk_widget_hide(w6);
w6=create_window6();
gtk_widget_show(w6);


GtkWidget *affich;
affich=lookup_widget(w6,"treeview3");
afficher_hotel_clientReserver(affich);

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  hotel d;
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
d=mod_hotel_client(h);
/*****Na3mlo Actualiser lil liste **************/

GtkWidget *fenetre_afficher;
GtkWidget *fenetre_ajout;
GtkWidget *treeview6;

fenetre_afficher=lookup_widget(button,"window6");
gtk_widget_hide(fenetre_afficher);
fenetre_ajout=create_window7();
gtk_widget_show(fenetre_ajout);
treeview6=lookup_widget(fenetre_ajout,"treeview4");
afficher_hotel_agent(treeview6);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window6");
gtk_widget_hide(w1);
w2=create_window10();
gtk_widget_show(w2);
}


void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button32_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window7");
gtk_widget_hide(w1);
w2=create_window6();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview3");
afficher_hotel_clientReserver(treeview1);
}


void
on_button33_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom,*Type,*Arrangement;
GtkWidget *Nb_jour,*Nb_personne,*label57;
char nom[20],type[20],arrangement[20];
int jour,personne;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Type=lookup_widget(button,"combobox8");
Arrangement=lookup_widget(button,"combobox9");
label57=lookup_widget(button,"label57");
Nb_jour=lookup_widget(button,"spinbutton8");
Nb_personne=lookup_widget(button,"spinbutton10");
Nom=lookup_widget(button,"entry3");

strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Type)));
strcpy(arrangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Arrangement)));
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_jour));
personne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_personne));
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(Nom)));

char r[500];

sprintf (r, "%f", recherche_prix_agent(h,nom,type,arrangement,jour,personne));
if (recherche_prix_agent(h,nom,type,arrangement,jour,personne) !=0)
{
char  tmp[50]="Le montant total est :";
strcat(tmp,r);
strcat(tmp," DT");
gtk_label_set_text(GTK_LABEL(label57),tmp);
}
else
gtk_label_set_text(GTK_LABEL(label57),"pas de hotel compatible");

}



void
on_button34_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom,*Type,*Arrangement;
GtkWidget *Nb_jour,*Nb_personne,*label84,*JOUR,*MOIS,*ANNEE;
char nom[20],type[20],arrangement[20];
int jour,personne,dt_jour,dt_mois,dt_annee;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Type=lookup_widget(button,"combobox8");
Arrangement=lookup_widget(button,"combobox9");
label84=lookup_widget(button,"label57");
Nb_jour=lookup_widget(button,"spinbutton8");
Nb_personne=lookup_widget(button,"spinbutton10");
JOUR=lookup_widget(button,"spinbutton9");
MOIS=lookup_widget(button,"spinbutton11");
ANNEE=lookup_widget(button,"spinbutton12");
Nom=lookup_widget(button,"entry3");


strcpy(h.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Type)));
strcpy(h.arrangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Arrangement)));
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_jour));
personne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_personne));
dt_jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
dt_mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
dt_annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));


char r1[20];
char r2[20];
char r3[20];
char r4[20]="";

sprintf(r1,"%d",dt_jour);
strcat(r4,r1);
strcat(r4,"/");
sprintf(r2,"%d",dt_mois);
strcat(r4,r2);
strcat(r4,"/");
sprintf(r3,"%d",dt_annee);
strcat(r4,r3);
float tmp=recherche_prix_agent(h,h.nom,h.type,h.arrangement,jour,personne);
if (tmp !=0)
{
reserver_hotel_client(h,tmp,r4);
gtk_label_set_text(GTK_LABEL(label84),"reservation reussite");
}
else
gtk_label_set_text(GTK_LABEL(label84),"pas de reservation");

}


void
on_button35_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window7");
gtk_widget_hide(w1);
w2=create_window10();
gtk_widget_show(w2);
}


void
on_button36_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button37_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window8");
gtk_widget_hide(w1);
w2=create_window1();
gtk_widget_show(w2);
}


void
on_button38_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button39_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button40_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
dell_hotel_agent(h);
GtkWidget *w8=lookup_widget(GTK_WIDGET(button),"window8");
gtk_widget_hide(w8);
w8=create_window8();
gtk_widget_show(w8);

GtkWidget *affich;
affich=lookup_widget(w8,"treeview5");
afficher_hotel_agentReserver(affich);

}


void
on_button41_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
  hotel d;
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
d=mod_hotel_agent(h);
/*****Na3mlo Actualiser lil liste **************/

GtkWidget *fenetre_afficher;
GtkWidget *fenetre_ajout;
GtkWidget *treeview6;

fenetre_afficher=lookup_widget(button,"window8");
gtk_widget_hide(fenetre_afficher);
fenetre_ajout=create_window9();
gtk_widget_show(fenetre_ajout);
treeview6=lookup_widget(fenetre_ajout,"treeview6");
afficher_hotel_agent(treeview6);
}


void
on_button42_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window8");
gtk_widget_hide(w1);
w2=create_window11();
gtk_widget_show(w2);
}


void
on_button45_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button43_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window9");
gtk_widget_hide(w1);
w2=create_window11();
gtk_widget_show(w2);
}


void
on_button44_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
exit(-1);
}


void
on_button47_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom,*Type,*Arrangement,*ID;
GtkWidget *Nb_jour,*Nb_personne,*label84,*JOUR,*MOIS,*ANNEE;
char nom[20],type[20],arrangement[20],id_client[20];
int jour,personne,dt_jour,dt_mois,dt_annee;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Type=lookup_widget(button,"combobox11");
Arrangement=lookup_widget(button,"combobox12");
label84=lookup_widget(button,"label84");
Nb_jour=lookup_widget(button,"spinbutton14");
Nb_personne=lookup_widget(button,"spinbutton15");
JOUR=lookup_widget(button,"spinbutton16");
MOIS=lookup_widget(button,"spinbutton17");
ANNEE=lookup_widget(button,"spinbutton18");
Nom=lookup_widget(button,"entry6");
ID=lookup_widget(button,"entry5");

strcpy(h.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Type)));
strcpy(h.arrangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Arrangement)));
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_jour));
personne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_personne));
dt_jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(JOUR));
dt_mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MOIS));
dt_annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ANNEE));
strcpy(h.nom,gtk_entry_get_text(GTK_ENTRY(Nom)));
strcpy(id_client,gtk_entry_get_text(GTK_ENTRY(ID)));

char r1[20];
char r2[20];
char r3[20];
char r4[20]="";

sprintf(r1,"%d",dt_jour);
strcat(r4,r1);
strcat(r4,"/");
sprintf(r2,"%d",dt_mois);
strcat(r4,r2);
strcat(r4,"/");
sprintf(r3,"%d",dt_annee);
strcat(r4,r3);
float tmp=recherche_prix_agent(h,h.nom,h.type,h.arrangement,jour,personne);
if (tmp !=0)
{
reserver_hotel_agent(h,tmp,id_client,r4);
gtk_label_set_text(GTK_LABEL(label84),"reservation reussite");
}
else
gtk_label_set_text(GTK_LABEL(label84),"pas de reservation");


}


void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Nom,*Type,*Arrangement;
GtkWidget *Nb_jour,*Nb_personne,*label84;
char nom[20],type[20],arrangement[20],id_client[20];
int jour,personne;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Type=lookup_widget(button,"combobox11");
Arrangement=lookup_widget(button,"combobox12");
label84=lookup_widget(button,"label84");
Nb_jour=lookup_widget(button,"spinbutton14");
Nb_personne=lookup_widget(button,"spinbutton15");
Nom=lookup_widget(button,"entry6");

strcpy(type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Type)));
strcpy(arrangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Arrangement)));
jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_jour));
personne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Nb_personne));
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(Nom)));

char r[500];

sprintf (r, "%f", recherche_prix_agent(h,nom,type,arrangement,jour,personne));
if (recherche_prix_agent(h,nom,type,arrangement,jour,personne) !=0)
{
char  tmp[50]="Le montant total est :";
strcat(tmp,r);
strcat(tmp," DT");
gtk_label_set_text(GTK_LABEL(label84),tmp);
}
else
gtk_label_set_text(GTK_LABEL(label84),"pas de hotel compatible");

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(v.id,str_data);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data, -1);

  }

strcpy(v.a,str_data);
}


void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Des;
GtkWidget *Et,*label98;
char t[20];
int k;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Des=lookup_widget(button,"combobox17");
label98=lookup_widget(button,"label99");
Et=lookup_widget(button,"spinbutton19");

strcpy(t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Des)));
k=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Et));
if(recherche_agent(h,k,t)==1)
{
w11=lookup_widget(button,"window10");
gtk_widget_hide(w11);
w9=create_window7();
gtk_widget_show(w9);
treeview6=lookup_widget(w9,"treeview4");
afficher_hotel_agent(treeview6);
}
else
gtk_label_set_text(GTK_LABEL(label98),"pas d'hotel compatible");

}



void
on_button49_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Des;
GtkWidget *Et,*label98;
char t[20];
int k;
hotel h;
GtkWidget *w11,*w9,*treeview6;
Des=lookup_widget(button,"combobox18");
label98=lookup_widget(button,"label98");
Et=lookup_widget(button,"spinbutton20");

strcpy(t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Des)));
k=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(Et));
if(recherche_agent(h,k,t)==1)
{
w11=lookup_widget(button,"window11");
gtk_widget_hide(w11);
w9=create_window9();
gtk_widget_show(w9);
treeview6=lookup_widget(w9,"treeview6");
afficher_hotel_agent(treeview6);
}
else
gtk_label_set_text(GTK_LABEL(label98),"pas d'hotel compatible");

}


void
on_button52_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window9");
gtk_widget_hide(w1);
w2=create_window8();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview5");
afficher_hotel_agentReserver(treeview1);
}


void
on_button50_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window10");
gtk_widget_hide(w1);
w2=create_window6();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview3");
afficher_hotel_clientReserver(treeview1);
}


void
on_button51_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2,*treeview1;
w1=lookup_widget(button,"window11");
gtk_widget_hide(w1);
w2=create_window8();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview5");
afficher_hotel_agentReserver(treeview1);
}


void
on_button53_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  
  w2=create_window12();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview7");
afficher_vol_dispo(treeview1);
}


void
on_button54_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1;
GtkWidget *w2;
GtkWidget *treeview1;
  
  w2=create_window12();
   gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview7");
afficher_vol_dispo(treeview1);
}


void
on_treeview5_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(h.id,str_data);
}


void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(h.nom,str_data);
}


void
on_button55_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1,*w2;
w1=lookup_widget(button,"window12");
gtk_widget_hide(w1);
}

