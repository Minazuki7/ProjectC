#include <gtk/gtk.h>


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
