#ifndef CLIENT_H_
#define CLIENT_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h" 
#include "client.h" 

struct Date 
{
int jour ;
int mois ;
int annee ;
}  ; 
typedef struct Date date;
struct   client
{ 
  date dt ;
   
  char nom[50] ; 
  char prenom[50] ;
  char email[100] ;
  char adresse[100] ;
  char mdp[50]  ;
  char cin[50] ;
  char cdp[50]  ; 
  char vnm[50]  ; 
char Bloc[50] ;  
char type[50];
};
typedef struct client client;
void ajouter (client x) ;
void afficher_Agents(GtkWidget *liste);
void dell_user(char *cin);
void afficher_rechercher(GtkWidget *liste,char c1[] ,char c2[],char c3[]);
#endif
