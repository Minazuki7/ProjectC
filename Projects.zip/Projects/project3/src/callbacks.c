#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h" 
#include "client.h"
#include <string.h> 
client x;
void
on_valider_clicked                     (GtkButton      *button,
                                        gpointer         user_data)
{ 
struct client x ;
GtkWidget *nom =lookup_widget (GTK_WIDGET(button),"nom");
GtkWidget *prenom=lookup_widget(GTK_WIDGET(button),"prenom");
GtkWidget *adresse=lookup_widget(GTK_WIDGET(button),"adresse");
GtkWidget *email=lookup_widget(GTK_WIDGET(button),"email") ;
GtkWidget *numero=lookup_widget(GTK_WIDGET(button),"numero");
GtkWidget *cin=lookup_widget(GTK_WIDGET(button),"cin");

GtkWidget *cdp=lookup_widget(GTK_WIDGET(button),"cp");
GtkWidget *mdp=lookup_widget(GTK_WIDGET(button),"mdp"); 
GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jour");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"mois");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"annee");
GtkWidget *tr=lookup_widget(GTK_WIDGET(button),"entry8");

GtkWidget *Bloc=lookup_widget(GTK_WIDGET(button),"combobox1") ;


if ((strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prenom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(adresse))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(email))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(numero))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(cin))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(cdp))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),"")==0)||(strcmp((gtk_combo_box_get_active_text(GTK_COMBO_BOX(Bloc))),"")==0))
{ 
g_print("non");
GtkWidget *dialog3;
dialog3=create_dialog3() ;
gtk_widget_show(dialog3) ;
}

else if(strcmp(gtk_entry_get_text(GTK_ENTRY(mdp)),gtk_entry_get_text(GTK_ENTRY(tr)))!=0)
{
g_print("dio4");
GtkWidget *dialog4;
dialog4=create_dialog4() ;
gtk_widget_show(dialog4) ;
}
else 
{
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(x.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(x.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(x.adresse,gtk_entry_get_text(GTK_ENTRY(adresse))) ;
strcpy(x.cin,gtk_entry_get_text(GTK_ENTRY(cin))) ;
strcpy(x.cdp,gtk_entry_get_text(GTK_ENTRY(cdp))); 
strcpy(x.vnm,gtk_entry_get_text(GTK_ENTRY(numero))) ;


strcpy(x.mdp,gtk_entry_get_text(GTK_ENTRY(mdp))) ;
x.dt.jour = (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
x.dt.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
x.dt.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

strcpy(x.Bloc,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Bloc))) ; 

GtkWidget *Message; //dialogue message // 

Message=create_dialog1();


gtk_widget_show(Message);
gtk_widget_show(Message) ;

ajouter (x) ;
}
};





void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Ajout_client =lookup_widget (GTK_WIDGET(button),"Ajout_client");
gtk_widget_destroy(Ajout_client); 
GtkWidget *Mes; //dialogue message // 

Mes=create_dialog2();


gtk_widget_show(Mes);
gtk_widget_show(Mes) ;
}


void
on_okbutton1_clicked                   (GtkButton       *button,      //dialogue message valider // 
                                        gpointer         user_data)
{
GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1")) ;
gtk_widget_destroy(dialog1) ;
}


void
on_gretour_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_grechercher_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *i1,*i2,*i3,*liste;
        i1=lookup_widget(button,"gnom");
	i2=lookup_widget(button,"gprenom");
	i3=lookup_widget(button,"gcin");
liste=lookup_widget(button,"treeview1");
afficher_rechercher(liste,gtk_entry_get_text(GTK_ENTRY(i1)) ,gtk_entry_get_text(GTK_ENTRY(i2)),gtk_entry_get_text(GTK_ENTRY(i3)));
GtkWidget *GestionsdesClients=lookup_widget(GTK_WIDGET(button),"Gestions_des_Clients");
GtkWidget *treeview1;

treeview1=lookup_widget(GestionsdesClients,"treeview1");

 afficher_Agents(treeview1);
gtk_widget_show(treeview1);

}


void
on_gmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{  
dell_user((char *)x.cin);
GtkWidget *Ajout_client ;
GtkWidget *gestion ;
GtkWidget *a,*b,*c,*d,*e,*f; 

Ajout_client=lookup_widget(button,"Ajout_client");
gestion=lookup_widget(button,"Gestions_des_Clients");
Ajout_client=create_Ajout_client() ;
gtk_widget_destroy(gestion);
gtk_widget_show(Ajout_client); 

a=lookup_widget(Ajout_client,"nom");
gtk_entry_set_text(GTK_LABEL(a),x.nom);
b=lookup_widget(Ajout_client,"prenom");
gtk_entry_set_text(GTK_LABEL(b),x.prenom);
c=lookup_widget(Ajout_client,"email");
gtk_entry_set_text(GTK_LABEL(c),x.email);
d=lookup_widget(Ajout_client,"adresse");
gtk_entry_set_text(GTK_LABEL(d),x.cin);
e=lookup_widget(Ajout_client,"numero");
gtk_entry_set_text(GTK_LABEL(e),x.vnm);
f=lookup_widget(Ajout_client,"cin");
gtk_entry_set_text(GTK_LABEL(f),x.adresse);

}


void
on_gajouter_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget* Ajout_client = create_Ajout_client ();
  gtk_widget_show (Ajout_client);

}


void
on_gsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)x.cin);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *GestionsdesClients=lookup_widget(GTK_WIDGET(button),"Gestions_des_Clients");
GtkWidget *treeview1;

treeview1=lookup_widget(GestionsdesClients,"treeview1");

 afficher_Agents(treeview1);
gtk_widget_show(treeview1);


}


void
on_bafficher_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *win1 ;
GtkWidget *win2 ; 
GtkWidget *treeview1 ;
win2=lookup_widget(button,"Ajout_client");
win1=lookup_widget(button,"Gestions_des_Clients");
win1=create_Gestions_des_Clients() ;
gtk_widget_destroy(win2);
gtk_widget_show(win1);
treeview1=lookup_widget(win1,"treeview1");
afficher_Agents(treeview1);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data,*str_data1,*str_data2,*str_data3,*str_data4,*str_data5;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data1, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data2, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data3, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data4, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data5, -1);

  }
strcpy(x.cin,str_data);
strcpy(x.nom,str_data1);
strcpy(x.prenom,str_data2);
strcpy(x.adresse,str_data3);
strcpy(x.vnm,str_data4);
strcpy(x.email,str_data5);

}


void
on_closebutton1_clicked                (GtkButton       *button,     //dialogue2 Message Quiter //
                                        gpointer         user_data)
{
GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2")) ;
gtk_widget_destroy(dialog2) ;
}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3")) ;
gtk_widget_destroy(dialog3) ;
}


void
on_okbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog4=lookup_widget(GTK_WIDGET(button),("dialog4")) ;
gtk_widget_destroy(dialog4) ;
}

