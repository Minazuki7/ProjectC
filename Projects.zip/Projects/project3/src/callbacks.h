#include <gtk/gtk.h>


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_gretour_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_grechercher_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_gmodifier_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_gajouter_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_gsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bafficher_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_okbutton3_clicked                   (GtkButton       *button,
                                        gpointer         user_data);
