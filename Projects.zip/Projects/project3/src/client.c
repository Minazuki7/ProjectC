#include "client.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{	
	
	c_NOM,
	c_PRENOM,
	c_EMAIL,
	c_CIN,
	c_TEL,
C_ADRESSE,
	COLUMNS
};

void ajouter (client x)
{


FILE *f;
strcpy(x.type,"Client") ;
f=fopen("client.bin","ab");
if(f!=NULL)
	{
	fwrite(&x,sizeof(client),1,f);
	}
fclose(f);

}
/*void ajouter (client x)
{
FILE *f;
strcpy(x.type,"Client") ;
f=fopen("client.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{ 
fprintf(f,"%s %s %s %s %s %s %s %s %s %d %d %d %s\n",x.nom,x.prenom,x.email,x.cin,x.adresse,x.mdp,x.cdp,x.Bloc,x.vnm,x.dt.jour,x.dt.mois,x.dt.annee,x.type);//écriture dans le fichier
}
fclose(f); //fermeture du fichier
} */
  
/***Afficher all  ***/

void afficher_Agents(GtkWidget *liste)
{
    GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Adresse ", renderer, "text",c_CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

        column = gtk_tree_view_column_new_with_attributes("cin ", renderer, "text",C_ADRESSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

int i=0;
FILE *f;
struct client x;
f=fopen("client.bin","rb"); //ouvrir un fichier en mode ajout

if(f!=NULL) //si le fichier est ouvert 
{ while(fread(&x,sizeof(client),1,f)==1)
i++ ;
/*fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d %s\n",x.nom,x.prenom,x.email,x.adresse,x.cin,x.vnm,x.mdp,x.cdp,x.Bloc,&x.dt.jour,&x.dt.mois,&x.dt.annee,x.type)!=EOF)
i++;*/
}

fclose(f);
 g_print("%d I ",i);
f=fopen("client.bin","rb"); 
if(f!=NULL)
{
g_print("\n8=");
int j=0;

while(j<i)
	{ 

      while(fread(&x,sizeof(client),1,f)==1)
		/*fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d %s\n",x.nom,x.prenom,x.email,x.adresse,x.cin,x.mdp,x.cdp,
x.Bloc,x.vnm,&x.dt.jour,&x.dt.mois,&x.dt.annee,x.type);	*/	
if(!(strcmp(x.type,"Client")))




		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_NOM,x.nom, c_PRENOM, x.prenom, c_EMAIL, x.email, c_CIN, x.cin ,c_TEL,x.vnm,C_ADRESSE,x.adresse, -1);}

 j++;
		}


fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);

}
gtk_widget_show(liste);

}



void dell_user(char *cin)
{client x;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("client_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("client.bin","rb");
new=fopen("client_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&x,1,sizeof(client),old);
	}
fclose(old);
old=fopen("client.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&x,1,sizeof(client),old);
	g_print("Psuedo  : %s\n",x.cin);
	if(strcmp(x.cin,cin))
		{	
		fwrite(&x,sizeof(client),1,new);
		}
	}
fclose(new);
fclose(old);
remove("client.bin");//nfas5ou il fichier li9dim
rename("client_test.bin","client.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **/
}


/*****************Rechercher***********************/  


void afficher_rechercher(GtkWidget *liste,char c1[] ,char c2[],char c3[])
{ GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter    iter;
	GtkListStore *store;

store=gtk_tree_view_get_model(liste); 
  if (store==NULL)
  store=gtk_tree_view_get_model(liste);

  if (store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Nom", renderer, "text",c_NOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Prenom", renderer, "text",c_PRENOM, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Email", renderer, "text",c_EMAIL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes(" Adresse ", renderer, "text",c_CIN, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("telephone", renderer, "text",c_TEL, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

        column = gtk_tree_view_column_new_with_attributes("cin ", renderer, "text",C_ADRESSE, NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
	}
store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,  		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, 		G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
struct client x;
FILE *f;

f=fopen("client.bin","rb");
int i=0;
while(!(feof(f)))
{
fread(&x,1,sizeof(client),f);
i++;
}
fclose(f);

f=fopen("client.bin","rb");
		if(strcmp(c1,"")==0)/*&&strcmp(c2,"")==0&&strcmp(c3,"")==0)*/
{
if(f!=NULL)

f=fopen("client.bin","rb"); //ouvrir un fichier en mode ajout

if(f!=NULL) //si le fichier est ouvert 
{ while(fread(&x,sizeof(client),1,f)==1)
i++ ; 
/*fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d %s\n",x.nom,x.prenom,x.email,x.adresse,x.cin,x.vnm,x.mdp,x.cdp,x.Bloc,&x.dt.jour,&x.dt.mois,&x.dt.annee,x.type)!=EOF)
i++;*/
}


fclose(f);
 g_print("%d I ",i);
f=fopen("client.bin","rb"); 
if(f!=NULL)
{
g_print("\n8=");
int j=0;

while(j<i)
	{ 

      while(fread(&x,sizeof(client),1,f)==1)
		/*fscanf(f,"%s %s %s %s %s %s %s %s %s %d %d %d %s\n",x.nom,x.prenom,x.email,x.adresse,x.cin,x.mdp,x.cdp,
x.Bloc,x.vnm,&x.dt.jour,&x.dt.mois,&x.dt.annee,x.type);	*/	
if(!(strcmp(x.type,"Client")))




		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_NOM,x.nom, c_PRENOM, x.prenom, c_EMAIL, x.email, c_CIN, x.cin ,c_TEL,x.vnm,C_ADRESSE,x.adresse, -1);}

 j++;
		}

fclose(f);
	gtk_tree_view_set_model (GTK_TREE_VIEW (liste),  GTK_TREE_MODEL (store));
        g_object_unref (store);

}
gtk_widget_show(liste);



if(strcmp(x.nom,c1)==0 ) //||strcmp(x.prenom,c2)==0||strcmp(x.cin,c3)==0)
		{gtk_list_store_append (store, &iter);
	
	gtk_list_store_set (store, &iter, c_NOM,x.nom, c_PRENOM, x.prenom, c_EMAIL, x.email, c_CIN, x.cin ,c_TEL,x.vnm,C_ADRESSE,x.adresse, -1);}

else
{if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&x,1,sizeof(client),f);


		if(strcmp(x.nom,c1)==0)/*||strcmp(x.prenom,c2)==0||strcmp(x.cin,c3)==0)*/
		{gtk_list_store_append (store, &iter);
		gtk_list_store_set (store, &iter, c_NOM,x.nom, c_PRENOM, x.prenom, c_EMAIL, x.email, c_CIN, x.cin ,c_TEL,x.vnm,C_ADRESSE,x.adresse, -1); }
         }
                }
}
}
}

 











