#ifndef FONCTION_H_
#define FONCTION_H_
void ajouter();
void afficher ();
int verifier (char log[],char mdp[],int r );
#endif 

