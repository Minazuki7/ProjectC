#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct authentification
{
char login[20], password [20];
int role;
}auth;
void ajouter()
{
auth a;
FILE *f;
int nbPersonnes=0,i;
f=fopen("/home/esprit/Projects/project2/src/fonc.txt","a+"); //ouvrir un fichier en mode ajout
if(f!=NULL) { //si le fichier est ouvert
for(i=0; i<1; i++) {//Ajout de 10 personnes
printf("Saisir les données");
fflush(stdin);
gets(a.login);
fflush(stdin);
gets(a.password);
fflush(stdin);
scanf("%d",&a.role);
fprintf(f,"%s %s %d \n",a.login,a.password,a.role);//écriture dans le fichier
}
fclose(f); //fermeture du fichier
}
}
void afficher ()
{ auth a;
int nbPersonnes=0;
FILE *f;
f=fopen("/home/esprit/Projects/project2/src/fonc.txt","r");//ouvertur du fichier en mode lecture
if(f !=NULL) {
while(fscanf(f,"%s %s %d \n",a.login,a.password,&a.role)!=EOF){ //parcours du fichier
nbPersonnes++;
printf("%s %s %d \n",a.login,a.password,a.role);
}}}
int verifier (char log[],char mdp[],int r )
{
auth a;
FILE *f;
r=0;
int i=0;
f=fopen("/home/esprit/Desktop/login/src/login.txt","r");
if(f !=NULL) {
while((fscanf(f,"%s %s %d \n",a.login,a.password,&a.role)!=EOF)) //parcours du fichier
{
if(strcmp(a.login,log)==0)
{ 
  if (strcmp(a.password,mdp)==0)
  r=a.role;
}
else if(r==0) 
{
r=-1;
}}
return r ;
}}
