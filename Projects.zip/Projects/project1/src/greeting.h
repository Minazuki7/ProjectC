void sayhello( char nom[],char hello[]) ; 

