#include <string.h> 
#include "greeting.h" 
 
void sayHello( char nom[],char hello[]) 
{       strcpy (hello,"Hello" ) ;
        strcat (hello , name ) ; 
}

