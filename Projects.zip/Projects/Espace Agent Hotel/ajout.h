typedef struct hotel hotel;
struct hotel
{char nom_hotel[20];
char adresse[20];
char etoile[10];
char num_responsable[20];
} ;
void ajout(char hotel_file[], hotel h);
