

#include <gtk/gtk.h>


struct hotel 
{char nom_hotel[20];
char adresse[20];
char etoile[10];
char num_responsable[20];
};
typedef struct hotel hotel  ;
void ajout (char hotel_file[], hotel h);
void afficher_hotel (GtkWidget * liste,hotel h);
void dell_user(char *etoiles) ;


// ("<span foreground=\"clor\"size=\"x-large\"><i><b> label </b> </i>/span>")) ;
