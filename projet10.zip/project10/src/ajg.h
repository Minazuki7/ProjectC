#ifndef AJG_H_
#define AJG_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_voll
{
int jour;
int mois;
int annee;
}date1;

typedef struct
{ 
date1 d;
date1 r;
char marq[20];
char lp[20];
char id[20]; 
}agent;

void ajout (agent *a); 
void affich (GtkWidget *liste,agent a);
void dell_a(char *marq);
#endif
