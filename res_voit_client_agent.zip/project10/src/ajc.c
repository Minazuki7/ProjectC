#include "ajc.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum 
{
 DEPART,
 ARRIVEE,
 MARQ,
 LP,
 COLUMNS
};
void ajouter (client *c)
{
FILE *f;
f=fopen("voiture.bin","ab"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(c,sizeof(client),1,f);
fclose(f); } //fermeture du fichier
}

void afficher (GtkWidget *liste,client c)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date de depart ", renderer,"text",DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Date d'arriver ", renderer,"text",ARRIVEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes(" Marque", renderer,"text",MARQ,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Lieu prise en charge", renderer,"text",LP,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

}
store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
int i=0 ;
f=fopen("voiture.bin","rb");
while (!(feof(f)))
{
fread (&c, sizeof(client),1,f);
 i++;
}
fclose(f);
g_print("\n i = %d",i);

f=fopen("voiture.bin","rb");
if(f!=NULL)
	{
	int j=0;
	while(j<i-1)
		{
		fread(&c,sizeof(client),1,f);
		//if(!(strcmp(c.lp,"lieu")))

char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_aller[20]="";
char dt_retour[20]="";

sprintf(r1,"%d",c.aller.jour);
strcat(dt_aller,r1);
strcat(dt_aller,"/");

sprintf(r2,"%d",c.aller.mois);
strcat(dt_aller,r2);
strcat(dt_aller,"/");

sprintf(r3,"%d",c.aller.annee);
strcat(dt_aller,r3);

sprintf(r4,"%d",c.retour.jour);
strcat(dt_retour,r4);
strcat(dt_retour,"/");
sprintf(r5,"%d",c.retour.mois);
strcat(dt_retour,r5);
strcat(dt_retour,"/");
sprintf(r6,"%d",c.retour.annee);
strcat(dt_retour,r6);
gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DEPART,dt_aller,ARRIVEE,dt_retour,MARQ,c.marq,LP,c.lp, -1);
j++; }
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}//fonction

void dell_user(char *marq)
{
client c;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("voiture_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("voiture.bin","rb");
new=fopen("voiture_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&c,1,sizeof(client),old);
	}
fclose(old);
old=fopen("voiture.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&c,1,sizeof(client),old);
	g_print("Psuedo  : %s\n",c.marq);
	if(strcmp(c.marq,marq))
		{	
		fwrite(&c,sizeof(client),1,new);
		}
	}
fclose(new);
fclose(old);
remove("voiture.bin");//nfas5ou il fichier li9dim
rename("voiture_test.bin","voiture.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}


