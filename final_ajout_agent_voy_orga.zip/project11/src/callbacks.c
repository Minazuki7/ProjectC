#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "vo.h"
voy a;

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
voy v;
GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jr");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"ms");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"an");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(button),"jr1");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(button),"ms1");
GtkWidget *an1=lookup_widget(GTK_WIDGET(button),"an1");
GtkWidget *c1=lookup_widget(GTK_WIDGET(button),"c1");
GtkWidget *e5=lookup_widget(GTK_WIDGET(button),"e5");
GtkWidget *e4=lookup_widget(GTK_WIDGET(button),"e4");
GtkWidget *e3=lookup_widget(GTK_WIDGET(button),"e3");
GtkWidget *e1=lookup_widget(GTK_WIDGET(button),"e1");

v.aller.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
v.aller.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
v.aller.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

v.retour.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
v.retour.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
v.retour.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));

strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(e5)));
strcpy(v.ti,gtk_entry_get_text(GTK_ENTRY(e4)));
strcpy(v.nh,gtk_entry_get_text(GTK_ENTRY(e1)));
strcpy(v.tr,gtk_entry_get_text(GTK_ENTRY(e3)));
strcpy(v.cl,gtk_combo_box_get_active_text(GTK_COMBO_BOX(c1)));

ajouter(&v);
}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
gtk_widget_destroy(window2);
window3=create_window3();
gtk_widget_show(window3);
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);

}


void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_destroy(window4);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ti,*nh,*cl,*tr;
dell_user((char *)a.ti);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window2=lookup_widget(button,"window2");
GtkWidget *window4=lookup_widget(button,"window4");
gtk_widget_hide(window4);
window2=create_window2();
gtk_widget_show(window2);


ti=lookup_widget(window2,"e4");
gtk_entry_set_text(GTK_LABEL(ti),a.ti);

nh=lookup_widget(window2,"e1");
gtk_entry_set_text(GTK_LABEL(nh),a.nh);

cl=lookup_widget(window2,"e3");
gtk_entry_set_text(GTK_LABEL(cl),a.cl);

tr=lookup_widget(window2,"e5");
gtk_entry_set_text(GTK_LABEL(tr),a.tr);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

dell_user((char *)a.ti);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *treeview1;

treeview1=lookup_widget(window4,"treeview1");

afficher(treeview1,a);
gtk_widget_show(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
gchar *str_data1,*str_data2,*str_data3;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data3, -1);
  }
strcpy(a.ti,str_data);
strcpy(a.nh,str_data1);
strcpy(a.cl,str_data2);
strcpy(a.tr,str_data3);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
voy v;
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");

GtkWidget *treeview1;
gtk_widget_destroy(window2);
window4=create_window4();
gtk_widget_show(window4);

treeview1=lookup_widget(window4,"treeview1");
afficher (treeview1,v);
}

