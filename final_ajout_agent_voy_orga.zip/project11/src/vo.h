#ifndef VO_H_
#define VO_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_vo
{
int jour;
int mois;
int annee;
}date;

typedef struct
{ 
date aller;
date retour;
char tr[20];
char prix[20];
char cl[20];
char nh[20];
char ti[20];
}voy;

void ajouter (voy *v); 
void afficher (GtkWidget *liste,voy v);
void dell_user(char *ti);
#endif
