#include<gtk/gtk.h>
#include<stdbool.h>
typedef struct
{
int jour;
int mois;
int annee;
}Date;
typedef struct
{
char id[10];
char classe[20];
char compagnie[20];
Date dt_depart;
char hr_depart[20];
char de[20];
char a[20];
float prix;
}ReservationVol;
typedef struct
{
char id[10];
char nom[30];
char destination[30];
int nbre_etoile;
float prix;
int nbre_jour;
int nbre_personne;
Date date_arrive;
char type[20];
char arrangement[20];
char date[20];
}hotel;

float vol_confirmation(ReservationVol tab,char classe[],char compagnie[],Date dt_depart,char hr_DEPART[],char de[],char a[]);
void reserver_vol(ReservationVol tab,float tmp);
void reserver_vol_agent(ReservationVol tab,float tmp);
void afficher_vol(GtkWidget *liste);
void afficher_vol_agent(GtkWidget *liste);
void dell_vol_agent(ReservationVol z);
int recherche_agent(hotel h,int nbre_etoile,char destination[]);
void afficher_hotel_agent(GtkWidget *liste);
float recherche_prix_agent(hotel h,char nom[],char type[],char arrangement[],int nb_jour,int nb_personne);
void reserver_hotel_agent(hotel h,float tmp,char id[],char date[]);
void afficher_hotel_agentReserver(GtkWidget *liste);
void reserver_hotel_client(hotel h,float tmp,char date[]);
void afficher_hotel_clientReserver(GtkWidget *liste);
ReservationVol mod_vol_agent(ReservationVol z);
void dell_vol_client(ReservationVol z);
ReservationVol mod_vol_client(ReservationVol z);
void afficher_vol_dispo(GtkWidget *liste);
void dell_hotel_agent(hotel z);
hotel mod_hotel_agent(hotel z);
void dell_hotel_client(hotel z);
hotel mod_hotel_client(hotel z);
