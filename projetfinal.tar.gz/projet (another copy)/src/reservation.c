#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"



float vol_confirmation(ReservationVol tab,char classe[],char compagnie[],Date dt_depart,char hr_DEPART[],char de[],char a[]){

 	FILE* f=fopen("gestion_vols.txt","r");
float fz=0;
int n=0;
if (f!=NULL)
{
while(!fz && fscanf(f,"%s %s %d %d %d %s %s %s %f",tab.de,tab.a,&tab.dt_depart.jour,&tab.dt_depart.mois,&tab.dt_depart.annee,tab.hr_depart,tab.classe,tab.compagnie,&tab.prix)!=EOF)
{


if ( (strcmp(tab.de,de)==0) && (strcmp(tab.a,a)==0)&& (strcmp(tab.hr_depart,hr_DEPART)==0) && (strcmp(tab.classe,classe)==0) && (strcmp(tab.compagnie,compagnie)==0))
{
if((tab.dt_depart.jour==dt_depart.jour) && (tab.dt_depart.mois==dt_depart.mois) && (tab.dt_depart.annee==dt_depart.annee))
{
printf("test");
fz= tab.prix;}}
else
return 0;
}

fclose(f);
}
return fz;
}





void reserver_vol(ReservationVol tab,float tmp)
{

FILE* f=fopen("volsReserve.txt","a+");
if(f!=NULL)
{


fprintf(f,"%s %s %d %d %d %s %s %s %f \n",tab.de,tab.a,tab.dt_depart.jour,tab.dt_depart.mois,tab.dt_depart.annee,tab.hr_depart,tab.classe,tab.compagnie,tmp);
fclose(f);
}
}
enum
{
    DE,
    A,
    DT_DEPART,
    HR_DEPART,
    CLASSE,
    COMPAGNIE,
    PRIX,
    COLUMNS
};

void afficher_vol(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
ReservationVol v;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" de",renderer,"text",DE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" a",renderer,"text",A,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" dt depart",renderer,"text",DT_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" hr depart",renderer,"text",HR_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" classe",renderer,"text",CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" compagnie",renderer,"text",COMPAGNIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("volsReserve.txt","r");
if (f==NULL)
{
return;
}
else
{
    f= fopen("volsReserve.txt","a+");
    while(fscanf(f,"%s %s %d %d %d %s %s %s %f \n",v.de,v.a,&v.dt_depart.jour,&v.dt_depart.mois,&v.dt_depart.annee,v.hr_depart,v.classe,v.compagnie,&v.prix)!=EOF)
    {
char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_depart[20]="";
char dt_retour[20]="";

sprintf(r1,"%d",v.dt_depart.jour);
strcat(dt_depart,r1);
strcat(dt_depart,"/");
sprintf(r2,"%d",v.dt_depart.mois);
strcat(dt_depart,r2);
strcat(dt_depart,"/");
sprintf(r3,"%d",v.dt_depart.annee);
strcat(dt_depart,r3);



gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,DE,v.de,A,v.a,DT_DEPART,dt_depart,HR_DEPART,v.hr_depart,CLASSE,v.classe,COMPAGNIE,v.compagnie,PRIX,v.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void reserver_vol_agent(ReservationVol tab,float tmp)
{

FILE* f=fopen("volsReserveAgent.txt","a+");
if(f!=NULL)
{


fprintf(f,"%s %s %s %d %d %d %s %s %s %f \n",tab.id,tab.de,tab.a,tab.dt_depart.jour,tab.dt_depart.mois,tab.dt_depart.annee,tab.hr_depart,tab.classe,tab.compagnie,tmp);
fclose(f);
}
}
enum
{
    _ID_Client,
    _DE,
    _A,
    _DT_DEPART,
    _CLASSE,
    _COMPAGNIE,
    _PRIX,
    _COLUMNS
};
void afficher_vol_agent(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
ReservationVol v;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",_ID_Client,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" de",renderer,"text",_DE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" a",renderer,"text",_A,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" dt depart",renderer,"text",_DT_DEPART,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" classe",renderer,"text",_CLASSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" compagnie",renderer,"text",_COMPAGNIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",_PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("volsReserveAgent.txt","a+");
if (f==NULL)
{
return;
}
else
{
  
    while(fscanf(f,"%s %s %s %d %d %d %s %s %s %f \n",v.id,v.de,v.a,&v.dt_depart.jour,&v.dt_depart.mois,&v.dt_depart.annee,v.hr_depart,v.classe,v.compagnie,&v.prix)!=EOF)
    {
char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_depart[20]="";


sprintf(r1,"%d",v.dt_depart.jour);
strcat(dt_depart,r1);
strcat(dt_depart,"/");
sprintf(r2,"%d",v.dt_depart.mois);
strcat(dt_depart,r2);
strcat(dt_depart,"/");
sprintf(r3,"%d",v.dt_depart.annee);
strcat(dt_depart,r3);
strcat(dt_depart," à ");
strcat(dt_depart,v.hr_depart);
strcat(dt_depart,"H");



gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,_ID_Client,v.id,_DE,v.de,_A,v.a,_DT_DEPART,dt_depart,_CLASSE,v.classe,_COMPAGNIE,v.compagnie,_PRIX,v.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}



void dell_vol_agent(ReservationVol z)
{
ReservationVol a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("volsReserveAgent.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	}
fclose(old);
old=fopen("volsReserveAgent.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fprintf(new,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,a.dt_depart.jour,a.dt_depart.mois,a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,a.prix);
		}
	}
fclose(new);
fclose(old);
remove("volsReserveAgent.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","volsReserveAgent.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}



ReservationVol mod_vol_agent(ReservationVol z)
{
ReservationVol a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("volsReserveAgent.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	}
fclose(old);
old=fopen("volsReserveAgent.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fprintf(new,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,a.dt_depart.jour,a.dt_depart.mois,a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,a.prix);
		}
        else  if(strcmp(a.id,z.id)==0)  
                {
        fscanf(new,"%s %s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
                return a;

                }
               
	}
fclose(new);
fclose(old);
remove("volsReserveAgent.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","volsReserveAgent.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}



void dell_vol_client(ReservationVol z)
{
ReservationVol a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("volsReserve.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	}
fclose(old);
old=fopen("volsReserve.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	
	if(strcmp(a.a,z.a)!=0)
		{	
		fprintf(new,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,a.dt_depart.jour,a.dt_depart.mois,a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,a.prix);
		}
	}
fclose(new);
fclose(old);
remove("volsReserve.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","volsReserve.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}



ReservationVol mod_vol_client(ReservationVol z)
{
ReservationVol a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("volsReserve.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	}
fclose(old);
old=fopen("volsReserve.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %d %d %d %s %s %s %f \n",a.id,a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
	
	if(strcmp(a.a,z.a)!=0)
		{	
		fprintf(new,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,a.dt_depart.jour,a.dt_depart.mois,a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,a.prix);
		}
        else  if(strcmp(a.a,z.a)==0)  
                {
        fscanf(new,"%s %s %d %d %d %s %s %s %f \n",a.de,a.a,&a.dt_depart.jour,&a.dt_depart.mois,&a.dt_depart.annee,a.hr_depart,a.classe,a.compagnie,&a.prix);
                return a;

                }
               
	}
fclose(new);
fclose(old);
remove("volsReserve.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","volsReserve.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}


int recherche_agent(hotel h,int nbre_etoile,char destination[])
{
	FILE* f=fopen("gestion_hotels.txt","r");
float fz=0;
int n=0;
if (f!=NULL)
{
while(!fz && fscanf(f,"%s %s %d %s %s %f",h.nom,h.destination,&h.nbre_etoile,h.type,h.arrangement,&h.prix)!=EOF)
{


if ( strcmp(h.destination,destination)==0)
{
if((h.nbre_etoile==nbre_etoile))
{
printf("test");
return 1;
}}
else
return 0;
}

fclose(f);
}

}




enum
{
    _NOM,
    _DESTINATION,
    _ETOILE,
    _TYPE,
    _ARRANGEMENT,
    _PRIXX,
    _COLUMNSS
};
void afficher_hotel_agent(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
hotel h;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" Nom",renderer,"text",_NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" destination",renderer,"text",_DESTINATION,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" etoile",renderer,"text",_ETOILE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",_TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" arrangement",renderer,"text",_ARRANGEMENT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",_PRIXX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(_COLUMNSS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("gestion_hotels.txt","a+");
if (f==NULL)
{
return;
}
else
{
  
    while(fscanf(f,"%s %s %d %s %s %f",h.nom,h.destination,&h.nbre_etoile,h.type,h.arrangement,&h.prix)!=EOF)
    {



gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,_NOM,h.nom,_DESTINATION,h.destination,_ETOILE,h.nbre_etoile,_TYPE,h.type,_ARRANGEMENT,h.arrangement,_PRIXX,h.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}



float recherche_prix_agent(hotel h,char nom[],char type[],char arrangement[],int nb_jour,int nb_personne)
{
	FILE* f=fopen("gestion_hotels.txt","r");
float fz=0;
int n=0;
if (f!=NULL)
{
while(!fz && fscanf(f,"%s %s %d %s %s %f",h.nom,h.destination,&h.nbre_etoile,h.type,h.arrangement,&h.prix)!=EOF)
{


if ( (strcmp(h.nom,nom)==0) && (strcmp(h.type,type)==0) && (strcmp(h.arrangement,arrangement)==0) )
{
fz=h.prix*nb_jour*nb_personne;
}
else
fz=0;
}

fclose(f);
}
return fz;
}

void reserver_hotel_agent(hotel h,float tmp,char id[],char date[])
{


FILE* f=fopen("hotelsReserveAgent.txt","a+");
if(f!=NULL)
{


fprintf(f,"%s %s  %s %s %s %f\n",id,h.nom,date,h.type,h.arrangement,tmp);
fclose(f);
}
}

enum
{
    _ID_Client_,
    _NOM_,
    _DT_ARRIVE,
    _TYPE_,
    _ARRANGEMT_,
    _PRIX_,
    _COLUMNS_
};


void afficher_hotel_agentReserver(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
hotel h;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",_ID_Client_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",_NOM_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" date arrivee",renderer,"text",_DT_ARRIVE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",_TYPE_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" arrangement",renderer,"text",_ARRANGEMT_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",_PRIX_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(_COLUMNS_,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("hotelsReserveAgent.txt","a+");
if (f==NULL)
{
return;
}
else
{
  
    while(fscanf(f,"%s %s %s %s %s %f\n",h.id,h.nom,h.date,h.type,h.arrangement,&h.prix)!=EOF)
    {


gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,_ID_Client_,h.id,_NOM_,h.nom,_DT_ARRIVE,h.date,_TYPE_,h.type,_ARRANGEMT_,h.arrangement,_PRIX_,h.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void reserver_hotel_client(hotel h,float tmp,char date[])
{


FILE* f=fopen("hotelsReserve.txt","a+");
if(f!=NULL)
{


fprintf(f,"%s %s %s %s %f\n",h.nom,date,h.type,h.arrangement,tmp);
fclose(f);
}
}

enum
{
    _NOMX_,
    _DT_ARRIVEX,
    _TYPEX_,
    _ARRANGEMTX_,
    _PRIXX_,
    _COLUMNSX_
};


void afficher_hotel_clientReserver(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
hotel h;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",_NOMX_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" date arrivee",renderer,"text",_DT_ARRIVEX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" type",renderer,"text",_TYPEX_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" arrangement",renderer,"text",_ARRANGEMTX_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",_PRIXX_,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(_COLUMNSX_,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("hotelsReserve.txt","a+");
if (f==NULL)
{
return;
}
else
{
  
    while(fscanf(f,"%s %s %s %s %f\n",h.nom,h.date,h.type,h.arrangement,&h.prix)!=EOF)
    {


gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,_NOMX_,h.nom,_DT_ARRIVEX,h.date,_TYPEX_,h.type,_ARRANGEMTX_,h.arrangement,_PRIXX_,h.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}
enum
{
    DE__,
    A__,
    DT_DEPART__,
    HR_DEPART__,
    CLASSE__,
    COMPAGNIE__,
    PRIX__,
    COLUMNS__
};

void afficher_vol_dispo(GtkWidget *liste)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter;
GtkListStore *store;


store=NULL;
FILE *f;
ReservationVol v;
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if(store==NULL)
{


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" de",renderer,"text",DE__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" a",renderer,"text",A__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" dt depart",renderer,"text",DT_DEPART__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" hr depart",renderer,"text",HR_DEPART__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" classe",renderer,"text",CLASSE__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" compagnie",renderer,"text",COMPAGNIE__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes(" prix",renderer,"text",PRIX__,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS__,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_FLOAT);

f=fopen("gestion_vols.txt","r");
if (f==NULL)
{
return;
}
else
{
    f= fopen("gestion_vols.txt","a+");
    while(fscanf(f,"%s %s %d %d %d %s %s %s %f \n",v.de,v.a,&v.dt_depart.jour,&v.dt_depart.mois,&v.dt_depart.annee,v.hr_depart,v.classe,v.compagnie,&v.prix)!=EOF)
    {
char r1[20];
char r2[20];
char r3[20];
char r4[20];
char r5[20];
char r6[20];
char dt_depart[20]="";
char dt_retour[20]="";

sprintf(r1,"%d",v.dt_depart.jour);
strcat(dt_depart,r1);
strcat(dt_depart,"/");
sprintf(r2,"%d",v.dt_depart.mois);
strcat(dt_depart,r2);
strcat(dt_depart,"/");
sprintf(r3,"%d",v.dt_depart.annee);
strcat(dt_depart,r3);



gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,DE__,v.de,A__,v.a,DT_DEPART__,dt_depart,HR_DEPART__,v.hr_depart,CLASSE__,v.classe,COMPAGNIE__,v.compagnie,PRIX__,v.prix,-1);
     }
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void dell_hotel_agent(hotel z)
{
hotel a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("hotelsReserveAgent.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,&a.prix);
	}
fclose(old);
old=fopen("hotelsReserveAgent.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,&a.prix);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fprintf(new,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,a.prix);
		}
	}
fclose(new);
fclose(old);
remove("hotelsReserveAgent.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","hotelsReserveAgent.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}



hotel mod_hotel_agent(hotel z)
{
hotel a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("hotelsReserveAgent.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,&a.prix);
	}
fclose(old);
old=fopen("hotelsReserveAgent.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,&a.prix);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fprintf(new,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,a.prix);
		}
        else  if(strcmp(a.id,z.id)==0)  
                {
        fscanf(new,"%s %s %s %s %s %f \n",a.id,a.nom,a.date,a.type,a.arrangement,&a.prix);
                return a;

                }
               
	}
fclose(new);
fclose(old);
remove("hotelsReserveAgent.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","hotelsReserveAgent.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}

void dell_hotel_client(hotel z)
{
hotel a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("hotelsReserve.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,&a.prix);
	}
fclose(old);
old=fopen("hotelsReserve.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,&a.prix);
	
	if(strcmp(a.nom,z.nom)!=0)
		{	
		fprintf(new,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,a.prix);
		}
	}
fclose(new);
fclose(old);
remove("hotelsReserve.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","hotelsReserve.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}



hotel mod_hotel_client(hotel z)
{
hotel a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("utilis.txt","w");
fclose(new);
/******copy data from old to new *******/
old=fopen("hotelsReserve.txt","r");
new=fopen("utilis.txt","a");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fscanf(old,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,&a.prix);
	}
fclose(old);
old=fopen("hotelsReserve.txt","r");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fscanf(old,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,&a.prix);
	
	if(strcmp(a.nom,z.nom)!=0)
		{	
		fprintf(new,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,a.prix);
		}
        else  if(strcmp(a.nom,z.nom)==0)  
                {
        fscanf(new,"%s %s %s %s %f \n",a.nom,a.date,a.type,a.arrangement,&a.prix);
                return a;

                }
               
	}
fclose(new);
fclose(old);
remove("hotelsReserve.txt");//nfas5ou il fichier li9dim
rename("utilis.txt","hotelsReserve.txt");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/

}


