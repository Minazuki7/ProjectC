#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonc.h"
GtkWidget *dialog2;
void on_button1_clicked (GtkButton *button,gpointer user_data)
{
////dialog2=create_dialog2();
gchar test[20];
int r;
GtkWidget *login;
GtkWidget *mdp;
GtkWidget *label;
label=lookup_widget(GTK_WIDGET(button),"label1");
login=lookup_widget(GTK_WIDGET(button),"entry1");
mdp=lookup_widget(GTK_WIDGET(button),"entry2");
//ajouter();
if(verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)),r)==1)
{


strcpy(test,"cv admin");
gtk_label_set_text(GTK_LABEL(label),test);
//gtk_widget_show (dialog2);
}
else if (verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)),r)==2)
{
strcpy(test,"agent");
}
else if (verifier(gtk_entry_get_text(GTK_ENTRY(login)),gtk_entry_get_text(GTK_ENTRY(mdp)),r)==-1)
{
strcpy(test,"NOOOO");
}
//gtk_label_set_text(GTK_LABEL(label),test);
}
void on_button_quitter_clicked (GtkButton *button,gpointer user_data)
{
gtk_main_quit();
}

