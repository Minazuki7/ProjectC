#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdio.h>
#include <string.h>
#include "personne.h"

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
 Personne p;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *fenetre_ajout;

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");

input1=lookup_widget(objet,"cin");
input2=lookup_widget(objet,"nom");
input3=lookup_widget(objet,"prenom");
input4=lookup_widget(objet,"date");
input5=lookup_widget(objet,"adresse");

strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY (input1)));
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY (input2)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY (input3)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY (input4)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY (input5)));

ajouter_personne(p);
}


void
on_affichier_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
gtk_widget_destroy(fenetre_ajout);

fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_personne(treeview1);
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajout=create_fenetre_ajout();
gtk_widget_show(fenetre_ajout);
}

