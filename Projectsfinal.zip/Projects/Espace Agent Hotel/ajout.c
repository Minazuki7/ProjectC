#include "ajout.h"
#include<stdio.h>
#include<stdlib.h>

void ajout (char hotel_file[], hotel h)
{
FILE *f;
f=fopen(hotel_file,"wb");
if (f!=NULL)
{
fwrite(&h,sizeof(hotel),1,f);
fclose(f);
}
}

