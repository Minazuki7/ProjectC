#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "hotel.h"

hotel h ;

void
on_valider_clicked                     (GtkWidget       *object,
                                        gpointer         user_data)
{
GtkWidget *input1 ;
GtkWidget *input2 ; 
GtkWidget *input3 ;
GtkWidget *input4;
hotel h;
input1=lookup_widget(object,"Nom_hotel");
input2=lookup_widget(object,"adresse");
input3=lookup_widget(object,"etoiles");/* GtkWidget *input3=lookup_widget(object,"spinbutton1");*/
input4=lookup_widget(object,"num_responsable");

if ((strcmp((gtk_entry_get_text(GTK_ENTRY(input1))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(input2))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(input3))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(input4))),"")==0))
{ 
g_print("non"); //dialogu1 promo hotel // 
GtkWidget *dialog1;
dialog1=create_dialog1() ;
gtk_widget_show(dialog1) ;
}
else
{
strcpy (h.nom_hotel,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.adresse,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.etoile,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.num_responsable,gtk_entry_get_text(GTK_ENTRY(input4)));
g_print("ajout_hotel worked");
ajout("ajout_hotel",h);
}
}



void
on_affiche_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;
  fenetre_ajout=lookup_widget(objet,"fenetre_ajout");
  gtk_widget_destroy(fenetre_ajout);
  fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
  fenetre_afficher=create_fenetre_afficher();
   gtk_widget_show(fenetre_afficher);
treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_hotel(treeview1,h);

}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fen_log,*fen2 ;
fen_log = lookup_widget(objet,"fenetre_ajout");
fen2 = lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fen2);
fen_log = create_fenetre_ajout();
gtk_widget_show(fen_log);

}


void
on_annuler_clicked                     (GtkButton       *button,
                                      gpointer         user_data)
{
gtk_main_quit();
}

void
on_hsupprimer_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)h.etoile);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *fenetreafficher=lookup_widget(GTK_WIDGET(button),"fenetre_afficher");
GtkWidget *treeview1;

treeview1=lookup_widget(fenetreafficher,"treeview1");

 afficher_hotel(treeview1,h);
gtk_widget_show(treeview1); 
GtkWidget *dialog2;
dialog2=create_dialog2() ;
gtk_widget_show(dialog2) ;
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

dell_user((char *)h.etoile);
GtkWidget *fenetre_afficher ,*fenetre_ajout;
GtkWidget *gestion ;
GtkWidget *a,*b,*c,*d; 

fenetre_afficher=lookup_widget(button,"fenetre_ajout");
gestion=lookup_widget(button,"fenetre_afficher");
fenetre_ajout=create_fenetre_ajout() ;
gtk_widget_destroy(gestion);
gtk_widget_show(fenetre_ajout);
 
g_print("hounii") ;

a=lookup_widget(fenetre_ajout,"Nom_hotel");
gtk_entry_set_text(GTK_LABEL(a),h.nom_hotel);

b=lookup_widget(fenetre_ajout,"adresse");
gtk_entry_set_text(GTK_LABEL(b),h.adresse);

c=lookup_widget(fenetre_ajout,"etoiles");
gtk_entry_set_text(GTK_LABEL(c),h.etoile);

d=lookup_widget(fenetre_ajout,"num_responsable");
gtk_entry_set_text(GTK_LABEL(d),h.num_responsable);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data,*str_data1,*str_data2,*str_data3;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data2, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data3, -1);
  }
strcpy(h.nom_hotel,str_data);
strcpy(h.adresse,str_data1);
strcpy(h.etoile,str_data2);
strcpy(h.num_responsable,str_data3);
}


void
on_okbutton1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1")) ;
gtk_widget_destroy(dialog1) ;
}


void
on_okbutton2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2")) ;
gtk_widget_destroy(dialog2) ;
}

