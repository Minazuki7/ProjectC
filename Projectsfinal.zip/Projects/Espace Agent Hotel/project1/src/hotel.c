#include "hotel.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<gtk/gtk.h>
enum
{
 HOTEL,
 ADRESSE,
 ETOILES,
 NUMERO,
 COLUMNS
};

void ajout (char hotel_file[], hotel h)
{
FILE *f;
f=fopen(hotel_file,"ab+");
if (f!=NULL)
{
fwrite(&h,sizeof(hotel),1,f);
fclose(f);
}
}
void afficher_hotel(GtkWidget *show,hotel h)
{
    
      GtkCellRenderer *render ;
      GtkTreeViewColumn *column;
      GtkTreeIter miter;
      GtkListStore *store ;
     
      char nom_hotel[20];
      char adresse[20];
      char etoile[10];
      char num_responsable[20];
    store = NULL;
     
      //FILE *f ;
      store =gtk_tree_view_get_model(GTK_TREE_VIEW(show));
      if(!store){
          render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("hotel",render,"text",HOTEL,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("adresse",render,"text",ADRESSE,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("etoiles",render,"text",ETOILES,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);

           render = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("responsable",render,"text",NUMERO,NULL);
          gtk_tree_view_append_column(GTK_TREE_VIEW(show),column);
          
          
      }
      store = gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


      FILE *f = fopen("ajout_hotel","rb") ;
      if(!f) exit(-1);

      while(fread(&h,sizeof(hotel),1,f)==1)
      {
          gtk_list_store_append(store,&miter);
          
          gtk_list_store_set(store,&miter,HOTEL,h.nom_hotel,ADRESSE,h.adresse,ETOILES,h.etoile,NUMERO,h.num_responsable);

      }
      fclose(f);
      gtk_tree_view_set_model(GTK_TREE_VIEW(show),GTK_TREE_MODEL(store));
      g_object_unref(store);





}
void dell_user(char *etoiles)
{hotel h;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("ajout_hotel_test","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajout_hotel","rb");
new=fopen("ajout_hotel_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&h,1,sizeof(hotel),old);
	}
fclose(old);
old=fopen("ajout_hotel","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&h,1,sizeof(hotel),old);
	
	if(strcmp(h.etoile,etoiles))
		{	
		fwrite(&h,sizeof(hotel),1,new);
		}
	}
fclose(new);
fclose(old);
remove("ajout_hotel");//nfas5ou il fichier li9dim
rename("ajout_hotel_test.bin","ajout_hotel");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **/
}


