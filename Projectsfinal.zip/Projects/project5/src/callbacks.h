#include <gtk/gtk.h>


void
on_buttonvalider_clicked               (GtkWidget *objet_graphique, gpointer user_data);

void
on_buttonconfirmer_clicked             (GtkWidget *objet_graphique, gpointer user_data);
