#include <gtk/gtk.h>
typedef struct 
{
 char id[20];
 char nom_hotels[20];
 char emplacement[20];
 int nb_etoile;
 char type_chambre[20];
 char arrangement[20];
 char prix_demi[20];
}A_hotels; 

void ajouter_hotels (A_hotels *a);
void afficher_hotels (GtkListItem * liste,A_hotels a);
void dell_user(char *nom);
void mod_user(A_hotels z,A_hotels b);
