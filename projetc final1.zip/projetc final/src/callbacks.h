#include <gtk/gtk.h>
#include"ajout.h"

void
on_bhotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bexcursion_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_bvoyades_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_bvoitures_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bucatalogue_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_bprec1_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_bquit1_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_bquit2_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_bprec2_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_ahotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_mhotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_shotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bajout1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bannuler1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_bprec3_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_bok_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_bmodiff_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_bprec9_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
