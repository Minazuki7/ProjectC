#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
A_hotels z;
A_hotels d;
A_hotels a;
void
on_bhotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w1 ;
GtkWidget *w2 ;
GtkWidget *treeview1 ;
w1=lookup_widget(button,"acc_agent");
gtk_widget_hide(w1);
w2=create_g_hotels();
gtk_widget_show(w2);
treeview1=lookup_widget(w2,"treeview1");
afficher_hotels(treeview1,a);

}
void
on_bexcursion_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bvoyades_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bvoitures_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bucatalogue_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bprec1_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bquit1_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
 gtk_main_quit();
}


void
on_bquit2_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
 gtk_main_quit();
}


void
on_bprec2_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w3 ;
GtkWidget *w4 ;
w3=lookup_widget(button,"g_hotels");
gtk_widget_hide(w3);
w4=create_acc_agent();
gtk_widget_show(w4);
}


void
on_ahotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w5 ;
GtkWidget *w6 ;
w5=lookup_widget(button,"g_hotels");
gtk_widget_hide(w5);
w6=create_a_hotels();
gtk_widget_show(w6);
}


void
on_mhotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id,*nom_hotels,*emplacement,*nb_etoil,*prix;
dell_user((char *)z.id);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *g_hotels=lookup_widget(button,"g_hotels");
GtkWidget *m_hotels=lookup_widget(button,"m_hotels");
gtk_widget_hide(g_hotels);
m_hotels=create_m_hotels();
gtk_widget_show(m_hotels);

id=lookup_widget(m_hotels,"entry_id1");
gtk_entry_set_text(GTK_ENTRY(id),z.id);

nom_hotels=lookup_widget(m_hotels,"entry_nomhotels1");
gtk_entry_set_text(GTK_ENTRY(nom_hotels),z.nom_hotels);

emplacement=lookup_widget(m_hotels,"entry_emplacement1");
gtk_entry_set_text(GTK_ENTRY(emplacement),z.emplacement);

emplacement=lookup_widget(m_hotels,"entry_emplacement1");
gtk_entry_set_text(GTK_ENTRY(emplacement),z.emplacement);

prix=lookup_widget(m_hotels,"entry_prix1");
gtk_entry_set_text(GTK_ENTRY(prix),z.prix_demi);
}


void
on_shotels_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)z.id);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *w10 ;
GtkWidget *treeview1;
w10=lookup_widget(button,"g_hotels");
gtk_widget_hide(w10);
w10=create_g_hotels();
gtk_widget_show(w10);

treeview1=lookup_widget(w10,"treeview1");
afficher_hotels(treeview1,a);

}


void
on_bajout1_clicked                     (GtkButton       *obj,
                                        gpointer         user_data)
{
 A_hotels z;
 GtkWidget *nomhotels;
 GtkWidget *emplace;
 GtkWidget *netoile;
 GtkWidget *id;
 GtkWidget *type;
 GtkWidget *arreng;
 GtkWidget *prix;
id=lookup_widget(obj,"entry_id");
nomhotels=lookup_widget(obj,"entry_nomhotels");
emplace=lookup_widget(obj,"entry_emplacement");
netoile=lookup_widget(obj,"spinbutton_etoil");
type=lookup_widget(obj,"combobox_chambre");
arreng=lookup_widget(obj,"combobox_arrangement");
prix=lookup_widget(obj,"entry_prix");
if((strcmp((gtk_entry_get_text(GTK_ENTRY(id))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(nomhotels))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(emplace))),"")==0)||(strcmp((gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))),"")==0)||(strcmp((gtk_combo_box_get_active_text(GTK_COMBO_BOX(arreng))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prix))),"")==0))
{ 
g_print("non");
GtkWidget *dialog1;
dialog1=create_dialog1() ;
gtk_widget_show(dialog1) ;
}
else
{
strcpy(z.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(z.nom_hotels,gtk_entry_get_text(GTK_ENTRY(nomhotels)));
strcpy(z.emplacement,gtk_entry_get_text(GTK_ENTRY(emplace)));
z.nb_etoile = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(netoile));
strcpy(z.type_chambre,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type)));
strcpy(z.arrangement,gtk_combo_box_get_active_text(GTK_COMBO_BOX(arreng)));
strcpy(z.prix_demi,gtk_entry_get_text(GTK_ENTRY(prix)));
ajouter_hotels (&z);
}
}


void
on_bannuler1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_bprec3_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
A_hotels a;
GtkWidget *w9 ;
GtkWidget *w10 ;
GtkWidget *treeview1;
w9=lookup_widget(button,"a_hotels");
gtk_widget_hide(w9);
w10=create_g_hotels();
gtk_widget_show(w10);
treeview1=lookup_widget(w10,"treeview1");
afficher_hotels(treeview1,a);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data,*str_data1,*str_data3,*str_data4,*str_data5,*str_data6;
int  *str_data2;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data3, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data4, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data5, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data6, -1);
  }
strcpy(z.id,str_data);
strcpy(z.nom_hotels,str_data1);
strcpy(z.emplacement,str_data3);
z.nb_etoile=str_data2;
strcpy(z.type_chambre,str_data4);
strcpy(z.arrangement,str_data5);
strcpy(z.prix_demi,str_data6);
}


void
on_bok_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *w3 ;
GtkWidget *w4 ;
GtkWidget *treeview1 ;
w3=lookup_widget(button,"ok_window");
gtk_widget_hide(w3);
w4=create_g_hotels();
gtk_widget_show(w4);
treeview1=lookup_widget(w4,"treeview1");
afficher_hotels(treeview1,a);
}



void
on_bprec9_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *w3 ;
GtkWidget *w4 ;
GtkWidget *treeview1 ;
w3=lookup_widget(button,"m_hotels");
gtk_widget_hide(w3);
w4=create_g_hotels();
gtk_widget_show(w4);
treeview1=lookup_widget(w4,"treeview1");
afficher_hotels(treeview1,a);

}


void
on_button8_clicked                     (GtkButton       *obj,
                                        gpointer         user_data)
{

GtkWidget  *nomhotels;
 GtkWidget *emplace;
 GtkWidget *netoile;
 GtkWidget *id;
 GtkWidget *type;
 GtkWidget *arreng;
 GtkWidget *prix;
id=lookup_widget(obj,"entry_id1");
nomhotels=lookup_widget(obj,"entry_nomhotels1");
emplace=lookup_widget(obj,"entry_emplacement1");
netoile=lookup_widget(obj,"spinbutton_etoil1");
type=lookup_widget(obj,"combobox_chambre1");
arreng=lookup_widget(obj,"combobox_arrangement1");
prix=lookup_widget(obj,"entry_prix1");
if((strcmp((gtk_entry_get_text(GTK_ENTRY(id))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(nomhotels))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(emplace))),"")==0)||(strcmp((gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))),"")==0)||(strcmp((gtk_combo_box_get_active_text(GTK_COMBO_BOX(arreng))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prix))),"")==0))
{ 
g_print("non");
GtkWidget *dialog1;
dialog1=create_dialog1() ;
gtk_widget_show(dialog1) ;
}
else
{
strcpy(z.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(z.nom_hotels,gtk_entry_get_text(GTK_ENTRY(nomhotels)));
strcpy(z.emplacement,gtk_entry_get_text(GTK_ENTRY(emplace)));
z.nb_etoile = (int)gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(netoile));
strcpy(z.prix_demi,gtk_entry_get_text(GTK_ENTRY(prix)));
ajouter_hotels (&z);
GtkWidget *w3 ;
GtkWidget *w4 ;
GtkWidget *treeview1 ;
w3=lookup_widget(obj,"m_hotels");
gtk_widget_hide(w3);
w4=create_g_hotels();
gtk_widget_show(w4);
treeview1=lookup_widget(w4,"treeview1");
afficher_hotels(treeview1,a);
}
}
