#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"ajout.h"
enum
{
 ID,
 NOMHOTELS,
 EMPLACEMENT,
 NOMBREETOILE,
 TYPE_CH,
 ARRG,
 PRIX,
 COLUMNS
};
void ajouter_hotels (A_hotels *a)
{
  FILE *f=fopen("ajouthotel.bin","ab+");
  if (f!=NULL)
    {
    fwrite(a,sizeof(A_hotels),1,f);
    }
    fclose(f);
}
void afficher_hotels (GtkListItem * liste,A_hotels a)
{
  
  GtkCellRenderer *renderer;
  GtkTreeViewColumn *column;
  GtkTreeIter iter;
  GtkListStore *store;
       store=NULL;
  
           FILE*f;
     store=gtk_tree_view_get_model(liste);
           if(store==NULL)
{
          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes(" id",renderer,"text",ID, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();

          column = gtk_tree_view_column_new_with_attributes(" nom_hotels",renderer,"text",NOMHOTELS, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();

          column = gtk_tree_view_column_new_with_attributes(" emplacement",renderer,"text",EMPLACEMENT, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();

          column = gtk_tree_view_column_new_with_attributes(" nb_etoile",renderer,"text",NOMBREETOILE, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
          renderer = gtk_cell_renderer_text_new();

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Type de chambre",renderer,"text",TYPE_CH, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          renderer = gtk_cell_renderer_text_new();
          column = gtk_tree_view_column_new_with_attributes("Arrangement",renderer,"text",ARRG, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

          column = gtk_tree_view_column_new_with_attributes(" prix_demi",renderer,"text",PRIX, NULL);
          gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
      store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_UINT, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
      int i=0;
      f= fopen("ajouthotel.bin","rb");
      while(!(feof(f)))
        {
           fread(&a,sizeof(A_hotels),1,f);
             i++;
             }
       fclose(f);
       f=fopen("ajouthotel.bin","rb");
      if(f!=NULL) 
        {
           int j=0; 
             while(j<i-1)
              {
                fread(&a,sizeof(A_hotels),1,f);
     gtk_list_store_append (store, &iter);
     gtk_list_store_set (store, &iter, ID, a.id, NOMHOTELS, a.nom_hotels, EMPLACEMENT, a.emplacement, NOMBREETOILE, a.nb_etoile, PRIX, a.prix_demi,TYPE_CH,a.type_chambre,ARRG,a.arrangement, -1); 
         j++;   }
              fclose(f);
       gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
       g_object_unref (store);
       }
}
}

void dell_user(char *id)
{
A_hotels a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("ajouthotel-test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajouthotel.bin","rb");
new=fopen("ajouthotel_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(A_hotels),old);
	}
fclose(old);
old=fopen("ajouthotel.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&a,1,sizeof(A_hotels),old);
	
	if(strcmp(a.id,id))
		{	
		fwrite(&a,sizeof(A_hotels),1,new);
		}
	}
fclose(new);
fclose(old);
remove("ajouthotel.bin");//nfas5ou il fichier li9dim
rename("ajouthotel_test.bin","ajouthotel.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}



//*********************************************************************************************//


void mod_user(A_hotels z,A_hotels b)
{
A_hotels a;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("ajouthotel_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("ajouthotel.bin","rb");
new=fopen("ajouthotel_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&a,1,sizeof(A_hotels),old);
	}
fclose(old);
old=fopen("ajouthotel.bin","rb");
/******************************/
int j=0;
while(j<i)
	{j++;
	fread(&a,1,sizeof(A_hotels),old);
	
	if(strcmp(a.id,z.id)!=0)
		{	
		fwrite(&a,sizeof(A_hotels),1,new);
		}
        else  if(strcmp(a.id,z.id)==0)  
                {
                fread(&b,1,sizeof(A_hotels),new);
                
                }
               
	}
fclose(new);
fclose(old);
remove("ajouthotel.bin");//nfas5ou il fichier li9dim
rename("ajouthotel_test.bin","ajouthotel.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
//return b;

/*****Na3mlo Actualiser lil liste **************/

}


