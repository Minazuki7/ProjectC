#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ajc.h"

client c ;
void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
gtk_widget_destroy(window1);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
client c;

GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jr");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"ms");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"an");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(button),"jr1");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(button),"ms1");
GtkWidget *an1=lookup_widget(GTK_WIDGET(button),"an1");
GtkWidget *marque=lookup_widget(GTK_WIDGET(button),"marque");
GtkWidget *lieu=lookup_widget(GTK_WIDGET(button),"lieu");


c.aller.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
c.aller.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
c.aller.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

c.retour.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
c.retour.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
c.retour.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));

strcpy(c.marq,gtk_combo_box_get_active_text(GTK_COMBO_BOX(marque)));
strcpy(c.lp,gtk_combo_box_get_active_text(GTK_COMBO_BOX(lieu)));

ajouter(&c);
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *sortie;
sortie=lookup_widget(button,"label5");
gtk_label_set_text(GTK_LABEL(sortie),"Reservation reussite :) ");
}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
client c;
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");

GtkWidget *treeview1;
gtk_widget_destroy(window2);
window3=create_window3();
gtk_widget_show(window3);

treeview1=lookup_widget(window3,"treeview1");
afficher (treeview1,c);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data, -1);
  }
strcpy(c.marq,str_data);
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);
}


void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

dell_user((char *)c.marq);

GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
GtkWidget *treeview1;

treeview1=lookup_widget(window3,"treeview1");

afficher(treeview1,c);
gtk_widget_show(treeview1);
}


void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}

